# MosquitoWatch - Smart Mosquito Breeding Spot Detection System

A mobile app plus a Flask backend. You photograph a place where water may collect (old tyres, buckets,
flower pots, tanks, drains, puddles); AI looks for objects that hold stagnant water, the spot is given a
risk level, placed on a map with its GPS position, and tracked until someone cleans it and marks it resolved.

```
new mobile app/
├── backend/            Flask API, AI detection, SQLite database
│   ├── app.py          app factory + entry point (python app.py)
│   ├── routes.py       REST API
│   ├── detector.py     YOLO / OpenCV detection (+ clearly-labelled demo mode)
│   ├── risk.py         risk scoring (low / medium / high) and cleaning advice
│   ├── auth.py         sign-in tokens, ESP32 device keys
│   ├── firebase_sync.py  optional Firebase Firestore copy of every report
│   ├── config.py, .env.example, requirements*.txt, Dockerfile, wsgi.py
│   ├── models/         put breeding_spots.pt (your trained YOLO weights) here
│   ├── train/          dataset.yaml + train_yolo.py to train your own model
│   └── tests/          automated API tests
└── mobile/             React Native (Expo) app
    ├── App.js, index.js, app.config.js, eas.json, package.json
    └── src/            screens, components, navigation, API client, theme
```

## Features (from the approval form)

| Feature | Where |
|---|---|
| AI breeding-spot detection (OpenCV + YOLO) | `backend/detector.py`, Scan tab |
| Risk-level classification | `backend/risk.py`, badges everywhere |
| GPS location | Scan tab reads the phone GPS; stored with every report |
| Photo evidence | original + annotated photo (boxes drawn by OpenCV) on the details screen |
| Real-time alerts | Alerts tab polls every 30 s, shows a badge and a pop-up for new high-risk spots |
| Hotspot monitoring | Map tab draws circles where 2+ active spots are within ~200 m |
| Weekly reports | Home > Weekly report (charts, risk split, object types, share) |
| Mark as resolved | Spot details > Mark as resolved (note + "after" photo), can be reopened |
| ESP32 + GPS module | `POST /api/reports` with the `X-Device-Key` header (see below) |
| Firebase storage | optional, `backend/firebase_sync.py` |

## 1. Run the backend

Requires Python 3.10+.

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate            # Windows      (Mac/Linux: source .venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env            # Mac/Linux: cp .env.example .env
python app.py
```

The API now runs on `http://localhost:5000`. Open `http://localhost:5000/api/health` to check it.

Run the tests any time with `python -m unittest discover -s tests -v`.

### Real AI detection vs demo mode

Out of the box the backend has **no trained model**, so it runs in **demo mode**: it returns
simulated detections (the same photo always gives the same result). Every simulated result is flagged in the
API and the app shows an orange "Demo detection" notice, so nobody mistakes it for a real result.

To get real detection:

1. `pip install -r requirements-ai.txt` (installs Ultralytics YOLO and PyTorch; large download).
2. Train weights on photos of your own area, following `backend/models/README.md`
   (`python train/train_yolo.py`), which writes `backend/models/breeding_spots.pt`.
3. Restart the backend. `DETECTOR_MODE=yolo` in `.env` makes it refuse to fall back to demo mode.

Without your own weights, YOLO loads the generic COCO model, which can only recognise bottles, cups, bowls,
vases and potted plants (it has no class for tyres, buckets, tanks, drains or puddles).

## 2. Run the mobile app

Requires Node.js 20+ and the **Expo Go** app on your phone (or an Android emulator / iOS simulator).

```bash
cd mobile
npm install
npx expo install --fix       # aligns every package with the Expo SDK version
copy .env.example .env       # then set EXPO_PUBLIC_API_URL (see below)
npx expo start
```

Scan the QR code with Expo Go (Android) or the Camera app (iOS). Your phone and computer must be on the
same Wi-Fi network.

**Server address.** A phone cannot reach `localhost` on your computer. Use your computer's Wi-Fi address:
find it with `ipconfig` (Windows, "IPv4 Address") or `ifconfig` (Mac/Linux), e.g. `http://192.168.1.20:5000`.
Put it in `mobile/.env` as `EXPO_PUBLIC_API_URL`, or type it in the app under **Server settings** on the sign-in
screen (or Settings after signing in) and tap **Save and test connection**. The Android emulator uses
`http://10.0.2.2:5000`. If the connection fails, allow Python through the Windows firewall for private networks.

If Expo Go says the project uses a different SDK version, run `npx expo install expo@latest --fix`
(or `expo@^56` to match an older Expo Go).

### Using the app

1. Create an account and sign in (accounts live in the backend database).
2. **Scan**: take a photo, check the location, optionally switch on "I can see standing water", then
   **Analyse and save report**. If nothing is detected, the photo is not saved unless you choose to.
3. **Reports** lists everything with filters; **Map** shows spots and hotspots; **Alerts** lists active
   high-risk spots.
4. When a place is cleaned, open it and tap **Mark as resolved**.

## 3. Build an installable APK (optional)

```bash
npm install -g eas-cli
cd mobile
eas login
eas build -p android --profile preview
```

Set the real backend URL in `eas.json` (`EXPO_PUBLIC_API_URL`) first, and host the backend somewhere your
phone can reach (see below). For a release build that shows the Google map, set `GOOGLE_MAPS_API_KEY`
before building (Expo Go does not need one).

## Deploying the backend

`backend/Dockerfile` runs the API with gunicorn:

```bash
cd backend
docker build -t mosquitowatch-api .
docker run -p 5000:5000 -e SECRET_KEY=$(openssl rand -hex 32) -v mw-data:/app/data -v mw-uploads:/app/uploads mosquitowatch-api
```

Any host that can run a Docker image or `gunicorn wsgi:app` works (Render, Railway, a VPS). Keep `data/` and
`uploads/` on persistent storage, and set a long random `SECRET_KEY`. Use HTTPS in production.

## ESP32 camera

Give the device a key: put `DEVICE_API_KEYS=my-long-random-key` in `backend/.env`. The ESP32 then sends a
multipart POST with a JPEG and the GPS position it read from its module:

```bash
curl -X POST http://SERVER:5000/api/reports \
  -H "X-Device-Key: my-long-random-key" \
  -F image=@photo.jpg -F latitude=19.0760 -F longitude=72.8777 -F address="Lane 4, drain camera"
```

These reports appear in the app like any other (marked as coming from an ESP32 camera). The Arduino/ESP32
firmware itself is not included in this folder.

## Firebase (optional)

`pip install -r requirements-firebase.txt`, download a service-account JSON from the Firebase console
(Project settings > Service accounts), and set `FIREBASE_CREDENTIALS=path/to/key.json` in `.env`. Every
created, resolved or reopened report is then copied to the `breeding_spots` Firestore collection. SQLite
remains the main database the app reads from. Never commit the key file.

## API summary

All endpoints except health, register and login need `Authorization: Bearer <token>`.

| Method and path | Purpose |
|---|---|
| `GET /api/health` | status and detector mode (no sign-in needed) |
| `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me` | accounts |
| `POST /api/reports` | upload photo + coordinates, run detection, save (also used by ESP32) |
| `GET /api/reports?status=&risk=&limit=&offset=` | list reports |
| `GET /api/reports/<id>` | one report |
| `POST /api/reports/<id>/resolve`, `/reopen` | close or reopen a spot |
| `GET /api/hotspots` | clusters of active spots |
| `GET /api/alerts?after_id=` | active high-risk spots |
| `GET /api/stats/summary`, `GET /api/stats/weekly?weeks_ago=` | dashboard and weekly report numbers |

## How risk is scored

Each detected object has a weight for how well it holds water (tyre, tank, drain, puddle = 3; bucket, pot,
container = 2; bottle = 1). Score = sum of weight x detection confidence x 15, plus a bonus if you
report visible standing water, capped at 100. **High** is 60 or more, **medium** 30 or more, otherwise
**low**. Edit `backend/risk.py` to tune it with your guide's input.

## Known limits

- Detection quality depends entirely on the model you train; demo mode is only for demonstrations.
- Alerts are checked by polling while the app is open. Push notifications when the app is closed need a
  development build and a push service, and are not included.
- The backend was tested with automated API tests and a live HTTP smoke test. The mobile code was
  syntax-checked, but it has not been run on a physical phone, so expect to fix small package-version
  or device-specific issues on first launch (`npx expo install --fix` handles most).
