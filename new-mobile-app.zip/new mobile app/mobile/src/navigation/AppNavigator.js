import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { Loading, Screen } from '../components/ui';
import { AlertsProvider, useAlerts } from '../context/AlertsContext';
import { useAuth } from '../context/AuthContext';
import AlertsScreen from '../screens/AlertsScreen';
import HomeScreen from '../screens/HomeScreen';
import LoginScreen from '../screens/LoginScreen';
import MapScreen from '../screens/MapScreen';
import RegisterScreen from '../screens/RegisterScreen';
import ReportDetailScreen from '../screens/ReportDetailScreen';
import ReportsScreen from '../screens/ReportsScreen';
import ScanScreen from '../screens/ScanScreen';
import SettingsScreen from '../screens/SettingsScreen';
import WeeklyReportScreen from '../screens/WeeklyReportScreen';
import { colors } from '../theme';
import { navigationRef } from './ref';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const icon = (name) => ({ color, size }) => <Ionicons name={name} size={size} color={color} />;

function Tabs() {
  const { unseen } = useAlerts();
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.pond,
        tabBarInactiveTintColor: colors.muted,
        tabBarLabelStyle: { fontSize: 12, fontWeight: '600' },
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.line },
      }}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ tabBarIcon: icon('home') }} />
      <Tab.Screen name="Reports" component={ReportsScreen} options={{ tabBarIcon: icon('list') }} />
      <Tab.Screen
        name="Scan"
        component={ScanScreen}
        options={{
          tabBarIcon: () => (
            <View style={styles.scanIcon}>
              <Ionicons name="camera" size={22} color="#FFFFFF" />
            </View>
          ),
          tabBarActiveTintColor: colors.pond,
        }}
      />
      <Tab.Screen name="Map" component={MapScreen} options={{ tabBarIcon: icon('map') }} />
      <Tab.Screen
        name="Alerts"
        component={AlertsScreen}
        options={{
          tabBarIcon: icon('notifications'),
          tabBarBadge: unseen > 0 ? unseen : undefined,
          tabBarBadgeStyle: { backgroundColor: colors.danger, color: '#FFFFFF' },
        }}
      />
    </Tab.Navigator>
  );
}

const headerOptions = {
  headerTintColor: colors.ink,
  headerStyle: { backgroundColor: colors.mist },
  headerShadowVisible: false,
  headerTitleStyle: { fontWeight: '700' },
  contentStyle: { backgroundColor: colors.mist },
};

function MainStack() {
  return (
    <AlertsProvider>
      <Stack.Navigator screenOptions={headerOptions}>
        <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
        <Stack.Screen name="ReportDetail" component={ReportDetailScreen} options={{ title: 'Spot details' }} />
        <Stack.Screen name="WeeklyReport" component={WeeklyReportScreen} options={{ title: 'Weekly report' }} />
        <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'Settings' }} />
      </Stack.Navigator>
    </AlertsProvider>
  );
}

function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ ...headerOptions, headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const { ready, user } = useAuth();
  if (!ready) {
    return (
      <Screen>
        <Loading />
      </Screen>
    );
  }
  return <NavigationContainer ref={navigationRef}>{user ? <MainStack /> : <AuthStack />}</NavigationContainer>;
}

const styles = StyleSheet.create({
  scanIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: colors.pond,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
});
