import { createNavigationContainerRef } from '@react-navigation/native';

// Lets code outside a screen (for example the alert pop-up) open a screen.
export const navigationRef = createNavigationContainerRef();
