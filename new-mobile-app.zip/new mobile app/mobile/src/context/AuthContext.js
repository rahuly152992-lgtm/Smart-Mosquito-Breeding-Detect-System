import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import * as SecureStore from 'expo-secure-store';

import * as api from '../api/client';
import { DEFAULT_API_URL } from '../config';

const KEYS = { token: 'auth_token', user: 'auth_user', server: 'server_url' };
const AuthContext = createContext(null);

async function read(key) {
  try {
    return await SecureStore.getItemAsync(key);
  } catch {
    return null;
  }
}

async function write(key, value) {
  try {
    if (value === null || value === undefined) await SecureStore.deleteItemAsync(key);
    else await SecureStore.setItemAsync(key, value);
  } catch {
    // Storage problems should never crash the app; the person just signs in again next time.
  }
}

export function AuthProvider({ children }) {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState(null);
  const [serverUrl, setServerUrlState] = useState(DEFAULT_API_URL);

  const signOut = useCallback(async () => {
    api.setToken(null);
    setUser(null);
    await write(KEYS.token, null);
    await write(KEYS.user, null);
  }, []);

  useEffect(() => {
    api.setUnauthorizedHandler(() => {
      signOut();
    });

    (async () => {
      const savedServer = await read(KEYS.server);
      if (savedServer) api.setBaseUrl(savedServer);
      setServerUrlState(api.getBaseUrl());

      const token = await read(KEYS.token);
      if (token) {
        api.setToken(token);
        const cached = await read(KEYS.user);
        try {
          const data = await api.me();
          setUser(data.user);
        } catch (e) {
          // 401 signs out through the handler above. If the server is just unreachable,
          // keep the saved session so the app still opens.
          if (e.status !== 401 && cached) setUser(JSON.parse(cached));
        }
      }
      setReady(true);
    })();
  }, [signOut]);

  const startSession = useCallback(async ({ token, user: account }) => {
    api.setToken(token);
    await write(KEYS.token, token);
    await write(KEYS.user, JSON.stringify(account));
    setUser(account);
  }, []);

  const value = useMemo(
    () => ({
      ready,
      user,
      serverUrl,
      signIn: async (email, password) => startSession(await api.login(email, password)),
      signUp: async (name, email, password) => startSession(await api.register(name, email, password)),
      signOut,
      setServer: async (url) => {
        api.setBaseUrl(url);
        setServerUrlState(api.getBaseUrl());
        await write(KEYS.server, api.getBaseUrl());
      },
    }),
    [ready, user, serverUrl, startSession, signOut]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
