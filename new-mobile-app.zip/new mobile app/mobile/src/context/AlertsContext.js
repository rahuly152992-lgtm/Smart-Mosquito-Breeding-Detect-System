import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, AppState } from 'react-native';

import * as api from '../api/client';
import { ALERT_POLL_MS } from '../config';
import { navigationRef } from '../navigation/ref';
import { reportTitle } from '../utils/format';

const AlertsContext = createContext(null);

// Polls the server for active high-risk spots, keeps the tab badge up to date and
// pops up a notice when a new one arrives while the app is open.
export function AlertsProvider({ children }) {
  const [alerts, setAlerts] = useState([]);
  const [seenId, setSeenId] = useState(0);
  const newestKnown = useRef(null);

  const refresh = useCallback(async () => {
    try {
      const data = await api.alerts();
      setAlerts(data.alerts);
      const newest = data.alerts.length ? data.alerts[0].id : 0;

      if (newestKnown.current !== null && newest > newestKnown.current) {
        const fresh = data.alerts.filter((a) => a.id > newestKnown.current);
        const extra = fresh.length > 1 ? ` and ${fresh.length - 1} more` : '';
        Alert.alert('New high-risk spot', `${reportTitle(fresh[0])}${extra} reported nearby.`, [
          { text: 'Later', style: 'cancel' },
          {
            text: 'View',
            onPress: () => navigationRef.isReady() && navigationRef.navigate('ReportDetail', { id: fresh[0].id }),
          },
        ]);
      }
      newestKnown.current = Math.max(newestKnown.current ?? 0, newest);
    } catch {
      // A failed poll is silent: the next one will try again.
    }
  }, []);

  useEffect(() => {
    refresh();
    const timer = setInterval(() => {
      if (AppState.currentState === 'active') refresh();
    }, ALERT_POLL_MS);
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') refresh();
    });
    return () => {
      clearInterval(timer);
      sub.remove();
    };
  }, [refresh]);

  const value = useMemo(
    () => ({
      alerts,
      unseen: alerts.filter((a) => a.id > seenId).length,
      refresh,
      markSeen: () => setSeenId(alerts.length ? alerts[0].id : 0),
    }),
    [alerts, seenId, refresh]
  );

  return <AlertsContext.Provider value={value}>{children}</AlertsContext.Provider>;
}

export const useAlerts = () => useContext(AlertsContext);
