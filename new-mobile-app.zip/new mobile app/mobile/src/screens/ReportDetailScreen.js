import React, { useCallback, useState } from 'react';
import { Alert, Image, Linking, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useFocusEffect } from '@react-navigation/native';

import * as api from '../api/client';
import { Banner, Button, Card, Chip, ErrorState, Field, Loading, RiskBadge, Screen } from '../components/ui';
import { colors, radius, space, type } from '../theme';
import { formatCoords, formatDateTime, labelText, placeText, reportTitle } from '../utils/format';

function Row({ icon, children }) {
  return (
    <View style={styles.infoRow}>
      <Ionicons name={icon} size={20} color={colors.muted} style={{ marginTop: 1 }} />
      <View style={{ flex: 1, marginLeft: space.md }}>{children}</View>
    </View>
  );
}

export default function ReportDetailScreen({ route }) {
  const { id, justCreated } = route.params;
  const [report, setReport] = useState(null);
  const [error, setError] = useState(null);
  const [view, setView] = useState('detected');
  const [resolving, setResolving] = useState(false);
  const [note, setNote] = useState('');
  const [afterPhoto, setAfterPhoto] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await api.getReport(id);
      setReport(data.report);
      setError(null);
    } catch (e) {
      setError(e.message);
    }
  }, [id]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const takeAfterPhoto = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Camera access needed', 'Allow camera access in your phone settings to add a photo.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.7 });
    if (!result.canceled) setAfterPhoto(result.assets[0]);
  };

  const confirmResolve = async () => {
    setBusy(true);
    try {
      const data = await api.resolveReport(id, { note: note.trim(), uri: afterPhoto?.uri });
      setReport(data.report);
      setResolving(false);
      setNote('');
      setAfterPhoto(null);
    } catch (e) {
      Alert.alert('Could not mark as resolved', e.message);
    } finally {
      setBusy(false);
    }
  };

  const reopen = () => {
    Alert.alert('Reopen this spot?', 'It will show as an active breeding spot again.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reopen',
        onPress: async () => {
          try {
            const data = await api.reopenReport(id);
            setReport(data.report);
          } catch (e) {
            Alert.alert('Could not reopen', e.message);
          }
        },
      },
    ]);
  };

  const openMaps = () => {
    const { latitude, longitude } = report;
    const url = Platform.select({
      ios: `http://maps.apple.com/?ll=${latitude},${longitude}&q=Breeding%20spot`,
      default: `geo:${latitude},${longitude}?q=${latitude},${longitude}(Breeding%20spot)`,
    });
    Linking.openURL(url).catch(() => Alert.alert('No maps app found', formatCoords(latitude, longitude)));
  };

  if (!report) {
    return (
      <Screen edges={[]}>{error ? <ErrorState message={error} onRetry={load} /> : <Loading />}</Screen>
    );
  }

  const resolved = report.status === 'resolved';
  const imageUri =
    view === 'original' ? api.assetUrl(report.original_image_url) : api.assetUrl(report.image_url);

  return (
    <Screen edges={[]}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {justCreated ? (
          <Banner tone="good" icon="checkmark-circle">
            Report saved. It is now visible on the map and to your team.
          </Banner>
        ) : null}
        {report.simulated ? (
          <Banner tone="warn" icon="flask">
            Demo detection: no trained AI model is loaded on the server, so these detections are simulated.
          </Banner>
        ) : null}

        <Text style={type.title}>{reportTitle(report)}</Text>
        <View style={styles.badges}>
          {resolved ? (
            <View style={styles.resolvedPill}>
              <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
              <Text style={styles.resolvedText}>Resolved</Text>
            </View>
          ) : (
            <RiskBadge level={report.risk_level} score={report.risk_score} />
          )}
        </View>

        <Image source={{ uri: imageUri }} style={styles.photo} resizeMode="cover" />
        {report.detections.length > 0 ? (
          <View style={styles.toggle}>
            <Chip label="Detected" active={view === 'detected'} onPress={() => setView('detected')} />
            <Chip label="Original" active={view === 'original'} onPress={() => setView('original')} />
          </View>
        ) : null}

        <Card style={{ marginTop: space.md }}>
          <Row icon="location-outline">
            <Text style={type.bodyStrong}>{placeText(report)}</Text>
            <Text style={type.small}>{formatCoords(report.latitude, report.longitude)}</Text>
            <Text style={styles.link} onPress={openMaps}>
              Open in Maps
            </Text>
          </Row>
          <Row icon="time-outline">
            <Text style={type.bodyStrong}>Reported {formatDateTime(report.created_at)}</Text>
            <Text style={type.small}>
              {report.reporter ? `By ${report.reporter}` : report.source === 'esp32' ? 'By an ESP32 camera' : ''}
            </Text>
          </Row>
          {report.water_present ? (
            <Row icon="water-outline">
              <Text style={type.bodyStrong}>Standing water was visible</Text>
            </Row>
          ) : null}
          {report.notes ? (
            <Row icon="document-text-outline">
              <Text style={type.body}>{report.notes}</Text>
            </Row>
          ) : null}
        </Card>

        {report.detections.length > 0 ? (
          <>
            <Text style={[type.heading, styles.section]}>What the AI found</Text>
            <Card>
              {report.detections.map((d, index) => (
                <View key={`${d.label}-${index}`} style={[styles.detRow, index > 0 && styles.detBorder]}>
                  <Text style={type.bodyStrong}>{labelText(d.label)}</Text>
                  <Text style={type.body}>{Math.round(d.confidence * 100)}% sure</Text>
                </View>
              ))}
            </Card>
          </>
        ) : null}

        {!resolved ? (
          <>
            <Text style={[type.heading, styles.section]}>What to do</Text>
            <Card>
              {report.advice.map((line, index) => (
                <View key={index} style={styles.adviceRow}>
                  <Ionicons name="checkmark" size={18} color={colors.pond} style={{ marginTop: 2 }} />
                  <Text style={[type.body, { flex: 1, marginLeft: space.sm, color: colors.ink }]}>{line}</Text>
                </View>
              ))}
            </Card>
          </>
        ) : (
          <>
            <Text style={[type.heading, styles.section]}>Resolved</Text>
            <Card>
              <Text style={type.bodyStrong}>Cleaned on {formatDateTime(report.resolved_at)}</Text>
              {report.resolution_note ? <Text style={[type.body, { marginTop: space.xs }]}>{report.resolution_note}</Text> : null}
              {report.resolved_image_url ? (
                <Image source={{ uri: api.assetUrl(report.resolved_image_url) }} style={styles.afterPhoto} />
              ) : null}
            </Card>
          </>
        )}

        <View style={{ marginTop: space.xl }}>
          {resolved ? (
            <Button title="Reopen this spot" variant="secondary" icon="refresh" onPress={reopen} />
          ) : resolving ? (
            <Card>
              <Text style={[type.heading, { marginBottom: space.md }]}>Mark as resolved</Text>
              <Field
                label="What was done? (optional)"
                value={note}
                onChangeText={setNote}
                placeholder="For example: emptied the bucket and turned it over"
                autoCapitalize="sentences"
                multiline
                maxLength={500}
              />
              {afterPhoto ? <Image source={{ uri: afterPhoto.uri }} style={styles.afterPhoto} /> : null}
              <Button
                title={afterPhoto ? 'Retake photo of the cleaned spot' : 'Add a photo of the cleaned spot'}
                icon="camera"
                variant="secondary"
                onPress={takeAfterPhoto}
              />
              <View style={styles.actionRow}>
                <Button title="Cancel" variant="ghost" onPress={() => setResolving(false)} style={{ flex: 1 }} />
                <View style={{ width: space.sm }} />
                <Button title="Mark as resolved" onPress={confirmResolve} loading={busy} style={{ flex: 1.4 }} />
              </View>
            </Card>
          ) : (
            <Button title="Mark as resolved" icon="checkmark-circle" onPress={() => setResolving(true)} />
          )}
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.lg, paddingBottom: space.xxl },
  badges: { flexDirection: 'row', marginTop: space.sm, marginBottom: space.lg },
  resolvedPill: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: colors.muted,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  resolvedText: { color: '#FFFFFF', fontWeight: '700', fontSize: 13, marginLeft: 4 },
  photo: { width: '100%', height: 260, borderRadius: radius.lg, backgroundColor: colors.line },
  toggle: { flexDirection: 'row', marginTop: space.md },
  infoRow: { flexDirection: 'row', paddingVertical: space.sm },
  link: { color: colors.pond, fontWeight: '700', fontSize: 14, marginTop: 4 },
  section: { marginTop: space.xl, marginBottom: space.md },
  detRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: space.sm },
  detBorder: { borderTopWidth: 1, borderTopColor: colors.line },
  adviceRow: { flexDirection: 'row', paddingVertical: 4 },
  afterPhoto: { width: '100%', height: 180, borderRadius: radius.md, marginVertical: space.md },
  actionRow: { flexDirection: 'row', marginTop: space.md },
});
