import React from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';

import { Button, Card, Screen } from '../components/ui';
import ServerSettings from '../components/ServerSettings';
import { useAuth } from '../context/AuthContext';
import { space, type } from '../theme';

export default function SettingsScreen() {
  const { user, signOut } = useAuth();

  const confirmSignOut = () =>
    Alert.alert('Sign out?', 'You will need to sign in again to see reports.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: signOut },
    ]);

  return (
    <Screen edges={[]}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Text style={[type.heading, styles.section]}>Account</Text>
        <Card>
          <Text style={type.bodyStrong}>{user?.name}</Text>
          <Text style={type.body}>{user?.email}</Text>
        </Card>

        <Text style={[type.heading, styles.section]}>Server</Text>
        <Card>
          <ServerSettings />
        </Card>

        <View style={{ marginTop: space.xl }}>
          <Button title="Sign out" variant="secondary" icon="log-out-outline" onPress={confirmSignOut} />
        </View>
        <Text style={[type.small, styles.version]}>MosquitoWatch 1.0.0</Text>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.lg, paddingBottom: space.xxl },
  section: { marginTop: space.lg, marginBottom: space.md },
  version: { textAlign: 'center', marginTop: space.xl },
});
