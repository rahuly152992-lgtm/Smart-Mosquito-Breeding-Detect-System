import React, { useCallback, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, Share, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';

import * as api from '../api/client';
import BarChart from '../components/BarChart';
import { Button, Card, EmptyState, ErrorState, Loading, Screen } from '../components/ui';
import { colors, radius, risk, space, type } from '../theme';
import { labelText, placeText, shortDate } from '../utils/format';

function Stat({ value, label, tone }) {
  return (
    <View style={styles.stat}>
      <Text style={[styles.statValue, tone && { color: tone }]}>{value}</Text>
      <Text style={type.small}>{label}</Text>
    </View>
  );
}

export default function WeeklyReportScreen() {
  const [weeksAgo, setWeeksAgo] = useState(0);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(
    async (pull = false) => {
      if (pull) setRefreshing(true);
      else setLoading(true);
      try {
        setData(await api.weekly(weeksAgo));
        setError(null);
      } catch (e) {
        setError(e.message);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [weeksAgo]
  );

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const shareReport = () => {
    if (!data) return;
    const types = data.by_type.map((t) => `${labelText(t.label)} (${t.count})`).join(', ') || 'none';
    Share.share({
      message:
        `Mosquito breeding report, ${shortDate(data.start)} to ${shortDate(data.end)}\n` +
        `New spots: ${data.new_reports} (${data.high_risk_new} high risk)\n` +
        `Resolved: ${data.resolved}\n` +
        `Still open from this week: ${data.still_active}\n` +
        `Most common objects: ${types}`,
    });
  };

  const maxType = data ? Math.max(1, ...data.by_type.map((t) => t.count)) : 1;

  return (
    <Screen edges={[]}>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} tintColor={colors.pond} />}
      >
        <View style={styles.weekNav}>
          <Pressable accessibilityLabel="Previous week" hitSlop={12} onPress={() => setWeeksAgo((w) => w + 1)}>
            <Ionicons name="chevron-back" size={26} color={colors.ink} />
          </Pressable>
          <View style={{ alignItems: 'center' }}>
            <Text style={type.heading}>{data ? `${shortDate(data.start)} – ${shortDate(data.end)}` : '…'}</Text>
            <Text style={type.small}>{weeksAgo === 0 ? 'Last 7 days' : weeksAgo === 1 ? 'Previous week' : `${weeksAgo} weeks ago`}</Text>
          </View>
          <Pressable
            accessibilityLabel="Next week"
            hitSlop={12}
            disabled={weeksAgo === 0}
            onPress={() => setWeeksAgo((w) => Math.max(0, w - 1))}
            style={{ opacity: weeksAgo === 0 ? 0.25 : 1 }}
          >
            <Ionicons name="chevron-forward" size={26} color={colors.ink} />
          </Pressable>
        </View>

        {loading ? (
          <Loading />
        ) : error && !data ? (
          <ErrorState message={error} onRetry={() => load()} />
        ) : (
          <>
            <Card style={styles.stats}>
              <Stat value={data.new_reports} label="New spots" />
              <Stat value={data.high_risk_new} label="High risk" tone={risk.high.color} />
              <Stat value={data.resolved} label="Resolved" tone={risk.low.color} />
              <Stat value={data.still_active} label="Still open" />
            </Card>

            <Text style={[type.heading, styles.section]}>Day by day</Text>
            <Card>
              <BarChart
                data={data.daily.map((d) => ({ label: d.weekday, a: d.new, b: d.resolved }))}
                colorA={colors.pond}
                colorB={risk.low.color}
              />
              <View style={styles.legend}>
                <View style={styles.legendItem}>
                  <View style={[styles.swatch, { backgroundColor: colors.pond }]} />
                  <Text style={type.small}>New</Text>
                </View>
                <View style={styles.legendItem}>
                  <View style={[styles.swatch, { backgroundColor: risk.low.color }]} />
                  <Text style={type.small}>Resolved</Text>
                </View>
              </View>
            </Card>

            <Text style={[type.heading, styles.section]}>By risk level</Text>
            <View style={styles.riskRow}>
              {['high', 'medium', 'low'].map((level) => (
                <View key={level} style={[styles.riskTile, { backgroundColor: risk[level].tint }]}>
                  <Text style={[styles.riskCount, { color: risk[level].color }]}>{data.by_risk[level]}</Text>
                  <Text style={[type.small, { color: risk[level].color, fontWeight: '700' }]}>{risk[level].label}</Text>
                </View>
              ))}
            </View>

            <Text style={[type.heading, styles.section]}>What was found</Text>
            {data.by_type.length === 0 ? (
              <EmptyState icon="leaf-outline" title="Nothing reported" message="No breeding objects were reported this week." />
            ) : (
              <Card>
                {data.by_type.map((t) => (
                  <View key={t.label} style={styles.typeRow}>
                    <Text style={styles.typeLabel}>{labelText(t.label)}</Text>
                    <View style={styles.typeTrack}>
                      <View style={[styles.typeFill, { width: `${(t.count / maxType) * 100}%` }]} />
                    </View>
                    <Text style={styles.typeCount}>{t.count}</Text>
                  </View>
                ))}
              </Card>
            )}

            {data.hotspots.length > 0 ? (
              <>
                <Text style={[type.heading, styles.section]}>Current hotspots</Text>
                <Card>
                  {data.hotspots.map((h, index) => (
                    <View key={index} style={[styles.hotRow, index > 0 && styles.hotBorder]}>
                      <View style={{ flex: 1 }}>
                        <Text style={type.bodyStrong}>
                          {h.count} open spots within {h.radius_m} m
                        </Text>
                        <Text style={type.small}>
                          {h.latitude.toFixed(4)}, {h.longitude.toFixed(4)}
                        </Text>
                      </View>
                      <Text style={[styles.hotLevel, { color: risk[h.risk_level].color }]}>{risk[h.risk_level].label}</Text>
                    </View>
                  ))}
                </Card>
              </>
            ) : null}

            <Button title="Share this report" icon="share-outline" variant="secondary" onPress={shareReport} style={{ marginTop: space.xl }} />
          </>
        )}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.lg, paddingBottom: space.xxl },
  weekNav: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: space.lg },
  stats: { flexDirection: 'row', justifyContent: 'space-between' },
  stat: { alignItems: 'center', flex: 1 },
  statValue: { fontSize: 30, fontWeight: '800', color: colors.ink, letterSpacing: -0.5 },
  section: { marginTop: space.xl, marginBottom: space.md },
  legend: { flexDirection: 'row', justifyContent: 'center', marginTop: space.md },
  legendItem: { flexDirection: 'row', alignItems: 'center', marginHorizontal: space.md },
  swatch: { width: 10, height: 10, borderRadius: 2, marginRight: 6 },
  riskRow: { flexDirection: 'row' },
  riskTile: { flex: 1, borderRadius: radius.md, padding: space.md, marginRight: space.sm, alignItems: 'center' },
  riskCount: { fontSize: 28, fontWeight: '800' },
  typeRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
  typeLabel: { width: 100, fontSize: 14, fontWeight: '600', color: colors.ink },
  typeTrack: { flex: 1, height: 10, borderRadius: 5, backgroundColor: colors.mist, overflow: 'hidden' },
  typeFill: { height: '100%', backgroundColor: colors.pond, borderRadius: 5 },
  typeCount: { width: 30, textAlign: 'right', fontWeight: '700', color: colors.ink },
  hotRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: space.sm },
  hotBorder: { borderTopWidth: 1, borderTopColor: colors.line },
  hotLevel: { fontWeight: '700', fontSize: 13 },
});
