import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Switch, Text, View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';

import * as api from '../api/client';
import { Banner, Button, Card, Field, Screen } from '../components/ui';
import { colors, radius, space, type } from '../theme';
import { formatCoords, labelText } from '../utils/format';

export default function ScanScreen({ navigation }) {
  const [photo, setPhoto] = useState(null);
  const [coords, setCoords] = useState(null);
  const [address, setAddress] = useState('');
  const [locating, setLocating] = useState(false);
  const [locError, setLocError] = useState(null);
  const [notes, setNotes] = useState('');
  const [water, setWater] = useState(false);
  const [busy, setBusy] = useState(false);
  const [cleanResult, setCleanResult] = useState(null);

  const locate = useCallback(async () => {
    setLocating(true);
    setLocError(null);
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== 'granted') {
        setLocError('Allow location access so the spot can be placed on the map.');
        return;
      }
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setCoords({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
      });
      try {
        const [place] = await Location.reverseGeocodeAsync(position.coords);
        if (place) {
          const parts = [place.name, place.street, place.district, place.city].filter(Boolean);
          setAddress([...new Set(parts)].join(', '));
        }
      } catch {
        // The street address is a nice extra; coordinates are enough.
      }
    } catch {
      setLocError('Could not read your location. Turn on GPS and try again.');
    } finally {
      setLocating(false);
    }
  }, []);

  useEffect(() => {
    locate();
  }, [locate]);

  const choosePhoto = (asset) => {
    setPhoto(asset);
    setCleanResult(null);
  };

  const takePhoto = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Camera access needed', 'Allow camera access in your phone settings to photograph a spot.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.7 });
    if (!result.canceled) choosePhoto(result.assets[0]);
  };

  const pickPhoto = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
    if (!result.canceled) choosePhoto(result.assets[0]);
  };

  const reset = () => {
    setPhoto(null);
    setNotes('');
    setWater(false);
    setCleanResult(null);
  };

  const submit = async (saveIfClean = false) => {
    if (!photo || !coords) return;
    setBusy(true);
    try {
      const data = await api.createReport({
        uri: photo.uri,
        latitude: coords.latitude,
        longitude: coords.longitude,
        address,
        notes: notes.trim(),
        waterPresent: water,
        saveIfClean,
      });
      if (data.saved) {
        reset();
        navigation.navigate('ReportDetail', { id: data.report.id, justCreated: true });
      } else {
        setCleanResult(data.analysis);
      }
    } catch (e) {
      Alert.alert('Could not analyse the photo', e.message);
    } finally {
      setBusy(false);
    }
  };

  const ready = !!photo && !!coords;

  return (
    <Screen>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={type.title}>Scan a spot</Text>
          <Text style={[type.body, { marginBottom: space.lg }]}>
            Photograph tyres, buckets, tanks, drains or puddles. The photo is checked for objects that hold stagnant water.
          </Text>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel={photo ? 'Change photo' : 'Take a photo'}
            onPress={takePhoto}
            style={styles.photoBox}
          >
            {photo ? (
              <Image source={{ uri: photo.uri }} style={styles.photo} resizeMode="cover" />
            ) : (
              <View style={styles.photoEmpty}>
                <Ionicons name="camera-outline" size={44} color={colors.pond} />
                <Text style={styles.photoEmptyText}>Tap to take a photo</Text>
              </View>
            )}
          </Pressable>
          <View style={styles.row}>
            <Button title={photo ? 'Retake' : 'Camera'} icon="camera" variant="secondary" onPress={takePhoto} style={{ flex: 1 }} />
            <View style={{ width: space.md }} />
            <Button title="Gallery" icon="images" variant="secondary" onPress={pickPhoto} style={{ flex: 1 }} />
          </View>

          <Card style={styles.block}>
            <View style={styles.locationRow}>
              <Ionicons name="location" size={22} color={coords ? colors.pond : colors.muted} />
              <View style={{ flex: 1, marginHorizontal: space.md }}>
                {coords ? (
                  <>
                    <Text style={type.bodyStrong} numberOfLines={2}>
                      {address || formatCoords(coords.latitude, coords.longitude)}
                    </Text>
                    <Text style={type.small}>
                      {formatCoords(coords.latitude, coords.longitude)}
                      {coords.accuracy ? ` · ±${Math.round(coords.accuracy)} m` : ''}
                    </Text>
                  </>
                ) : (
                  <Text style={type.body}>{locating ? 'Finding your location…' : locError || 'Location not set'}</Text>
                )}
              </View>
              <Pressable onPress={locate} hitSlop={10} accessibilityLabel="Refresh location" disabled={locating}>
                <Ionicons name="refresh" size={22} color={colors.pond} />
              </Pressable>
            </View>
          </Card>

          <Card style={styles.block}>
            <View style={styles.locationRow}>
              <View style={{ flex: 1, marginRight: space.md }}>
                <Text style={type.bodyStrong}>I can see standing water</Text>
                <Text style={type.small}>Raises the risk level, even if the photo shows no object.</Text>
              </View>
              <Switch
                value={water}
                onValueChange={setWater}
                trackColor={{ true: colors.pond, false: colors.line }}
                thumbColor="#FFFFFF"
              />
            </View>
          </Card>

          <Field
            label="Notes (optional)"
            value={notes}
            onChangeText={setNotes}
            placeholder="For example: behind the shop, near the gate"
            autoCapitalize="sentences"
            multiline
            maxLength={500}
            style={{ marginTop: space.lg }}
          />

          {cleanResult ? (
            <Card style={{ marginBottom: space.lg }}>
              <Text style={type.heading}>No breeding objects found</Text>
              <Text style={[type.body, { marginTop: space.xs, marginBottom: space.md }]}>
                Nothing in this photo looks like it holds stagnant water. Try a closer photo, or save it anyway if you
                want it tracked.
              </Text>
              {cleanResult.simulated ? (
                <Banner tone="warn" icon="flask">
                  Demo detection is running on the server, so this result is simulated.
                </Banner>
              ) : null}
              <Button title="Save as a report anyway" variant="secondary" onPress={() => submit(true)} loading={busy} />
            </Card>
          ) : null}

          <Button
            title="Analyse and save report"
            icon="scan"
            onPress={() => submit(false)}
            loading={busy}
            disabled={!ready}
          />
          {!ready ? (
            <Text style={[type.small, styles.hint]}>
              {!photo ? 'Add a photo to continue.' : 'Waiting for your location.'}
            </Text>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.lg, paddingBottom: space.xxl },
  photoBox: {
    height: 230,
    borderRadius: radius.lg,
    overflow: 'hidden',
    backgroundColor: colors.pondTint,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    borderColor: colors.pond,
    marginBottom: space.md,
  },
  photo: { width: '100%', height: '100%' },
  photoEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  photoEmptyText: { marginTop: space.sm, color: colors.pondDark, fontWeight: '600', fontSize: 15 },
  row: { flexDirection: 'row' },
  block: { marginTop: space.md, padding: space.md },
  locationRow: { flexDirection: 'row', alignItems: 'center' },
  hint: { textAlign: 'center', marginTop: space.sm },
});
