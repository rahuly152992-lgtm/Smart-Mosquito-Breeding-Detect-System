import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Banner, Button, Field, Screen } from '../components/ui';
import ServerSettings from '../components/ServerSettings';
import { useAuth } from '../context/AuthContext';
import { colors, radius, space, type } from '../theme';

export default function LoginScreen({ navigation }) {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [showServer, setShowServer] = useState(false);

  const submit = async () => {
    if (!email.trim() || !password) {
      setError('Enter your email and password.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await signIn(email.trim(), password);
    } catch (e) {
      setError(e.message);
      setBusy(false);
    }
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.logo}>
            <Ionicons name="water" size={34} color="#FFFFFF" />
          </View>
          <Text style={[type.title, styles.title]}>MosquitoWatch</Text>
          <Text style={[type.body, styles.subtitle]}>
            Photograph places where water collects, and the app tells you which ones are likely to breed mosquitoes.
          </Text>

          {error ? (
            <Banner tone="bad" icon="alert-circle">
              {error}
            </Banner>
          ) : null}

          <Field
            label="Email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoComplete="email"
            textContentType="emailAddress"
          />
          <Field
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoComplete="password"
            textContentType="password"
            onSubmitEditing={submit}
          />
          <Button title="Sign in" onPress={submit} loading={busy} />
          <Button title="Create an account" variant="ghost" onPress={() => navigation.navigate('Register')} style={{ marginTop: space.sm }} />

          <Pressable onPress={() => setShowServer((v) => !v)} style={styles.serverToggle} hitSlop={8}>
            <Ionicons name="server-outline" size={18} color={colors.pond} />
            <Text style={styles.serverToggleText}>{showServer ? 'Hide server settings' : 'Server settings'}</Text>
          </Pressable>
          {showServer ? <ServerSettings /> : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.xl, paddingTop: space.xxl },
  logo: {
    width: 64,
    height: 64,
    borderRadius: radius.lg,
    backgroundColor: colors.pond,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: space.lg,
  },
  title: { marginBottom: space.sm },
  subtitle: { marginBottom: space.xl },
  serverToggle: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginVertical: space.xl },
  serverToggleText: { marginLeft: 6, color: colors.pond, fontWeight: '600', fontSize: 15 },
});
