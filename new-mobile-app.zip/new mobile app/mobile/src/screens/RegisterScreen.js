import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text } from 'react-native';

import { Banner, Button, Field, Screen } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { space, type } from '../theme';

export default function RegisterScreen({ navigation }) {
  const { signUp } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (name.trim().length < 2) return setError('Enter your name.');
    if (!email.trim()) return setError('Enter your email address.');
    if (password.length < 6) return setError('Choose a password with at least 6 characters.');
    setBusy(true);
    setError(null);
    try {
      await signUp(name.trim(), email.trim(), password);
    } catch (e) {
      setError(e.message);
      setBusy(false);
    }
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={[type.title, { marginBottom: space.sm }]}>Create your account</Text>
          <Text style={[type.body, { marginBottom: space.xl }]}>
            Your name is shown on the spots you report.
          </Text>
          {error ? (
            <Banner tone="bad" icon="alert-circle">
              {error}
            </Banner>
          ) : null}
          <Field label="Name" value={name} onChangeText={setName} autoCapitalize="words" textContentType="name" />
          <Field
            label="Email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            textContentType="emailAddress"
          />
          <Field
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            textContentType="newPassword"
            onSubmitEditing={submit}
          />
          <Button title="Create account" onPress={submit} loading={busy} />
          <Button title="I already have an account" variant="ghost" onPress={() => navigation.goBack()} style={{ marginTop: space.sm }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.xl, paddingTop: space.xxl },
});
