import React from 'react';
import { Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import * as api from '../api/client';
import ReportCard from '../components/ReportCard';
import { Button, EmptyState, ErrorState, Loading, Screen, SectionTitle } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { colors, radius, risk, space, type } from '../theme';
import { useFocusFetch } from '../utils/hooks';

function RiskBar({ counts }) {
  const total = counts.high + counts.medium + counts.low;
  if (total === 0) return <View style={[styles.bar, { backgroundColor: 'rgba(255,255,255,0.18)' }]} />;
  return (
    <View style={styles.bar}>
      {['high', 'medium', 'low'].map((level) =>
        counts[level] > 0 ? <View key={level} style={{ flex: counts[level], backgroundColor: risk[level].color }} /> : null
      )}
    </View>
  );
}

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const { data, error, loading, refreshing, refresh, reload } = useFocusFetch(async () => {
    const [summary, urgent] = await Promise.all([
      api.summary(),
      api.listReports({ status: 'active', risk: 'high', limit: 5 }),
    ]);
    return { summary, urgent: urgent.reports };
  });

  const firstName = (user?.name || '').split(' ')[0];
  const summary = data?.summary;

  return (
    <Screen>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={colors.pond} />}
      >
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={type.title}>{firstName ? `Hello, ${firstName}` : 'Hello'}</Text>
            <Text style={type.body}>Here is what needs attention today.</Text>
          </View>
          <Pressable accessibilityLabel="Settings" onPress={() => navigation.navigate('Settings')} hitSlop={12}>
            <Ionicons name="settings-outline" size={25} color={colors.ink} />
          </Pressable>
        </View>

        {loading ? (
          <Loading />
        ) : error && !data ? (
          <ErrorState message={error} onRetry={reload} />
        ) : (
          <>
            <View style={styles.panel}>
              <Text style={styles.panelLabel}>Open breeding spots</Text>
              <Text style={styles.panelNumber}>{summary.active}</Text>
              <RiskBar counts={summary.active_by_risk} />
              <View style={styles.legend}>
                {['high', 'medium', 'low'].map((level) => (
                  <View key={level} style={styles.legendItem}>
                    <View style={[styles.dot, { backgroundColor: risk[level].color }]} />
                    <Text style={styles.legendText}>
                      {summary.active_by_risk[level]} {level}
                    </Text>
                  </View>
                ))}
              </View>
              <View style={styles.panelFoot}>
                <Text style={styles.footText}>{summary.new_today} new today</Text>
                <Text style={styles.footText}>{summary.hotspot_count} hotspots</Text>
                <Text style={styles.footText}>{summary.resolved} resolved</Text>
              </View>
            </View>

            <View style={styles.actions}>
              <Button title="Scan a spot" icon="camera" onPress={() => navigation.navigate('Scan')} style={{ flex: 1 }} />
              <View style={{ width: space.md }} />
              <Button
                title="Weekly report"
                icon="bar-chart"
                variant="secondary"
                onPress={() => navigation.navigate('WeeklyReport')}
                style={{ flex: 1 }}
              />
            </View>

            <SectionTitle
              right={
                <Pressable onPress={() => navigation.navigate('Alerts')} hitSlop={8}>
                  <Text style={styles.link}>All alerts</Text>
                </Pressable>
              }
            >
              Needs attention
            </SectionTitle>
            {data.urgent.length === 0 ? (
              <EmptyState
                icon="shield-checkmark-outline"
                title="No high-risk spots"
                message="When someone reports a high-risk breeding spot, it appears here."
              />
            ) : (
              data.urgent.map((report) => (
                <ReportCard
                  key={report.id}
                  report={report}
                  onPress={() => navigation.navigate('ReportDetail', { id: report.id })}
                />
              ))
            )}
          </>
        )}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.lg, paddingBottom: space.xxl },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: space.lg },
  panel: { backgroundColor: colors.ink, borderRadius: radius.lg, padding: space.xl },
  panelLabel: { color: '#B9C8CC', fontSize: 15, fontWeight: '600' },
  panelNumber: { color: '#FFFFFF', fontSize: 56, fontWeight: '800', letterSpacing: -1.5, marginBottom: space.md },
  bar: { height: 12, borderRadius: 6, overflow: 'hidden', flexDirection: 'row' },
  legend: { flexDirection: 'row', marginTop: space.md },
  legendItem: { flexDirection: 'row', alignItems: 'center', marginRight: space.lg },
  dot: { width: 9, height: 9, borderRadius: 5, marginRight: 6 },
  legendText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },
  panelFoot: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: space.lg,
    paddingTop: space.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.15)',
  },
  footText: { color: '#B9C8CC', fontSize: 13, fontWeight: '600' },
  actions: { flexDirection: 'row', marginTop: space.lg },
  link: { color: colors.pond, fontWeight: '700', fontSize: 15 },
});
