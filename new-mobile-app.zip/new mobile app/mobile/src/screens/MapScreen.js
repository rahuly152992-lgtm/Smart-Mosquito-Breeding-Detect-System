import React, { useCallback, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import MapView, { Callout, Circle, Marker } from 'react-native-maps';
import { useFocusEffect } from '@react-navigation/native';

import * as api from '../api/client';
import { Chip, ErrorState, Loading, Screen } from '../components/ui';
import { DEFAULT_REGION } from '../config';
import { colors, radius, risk, space, type } from '../theme';
import { reportTitle } from '../utils/format';

export default function MapScreen({ navigation }) {
  const mapRef = useRef(null);
  const fitted = useRef(false);
  const [filter, setFilter] = useState('active');
  const [reports, setReports] = useState([]);
  const [hotspots, setHotspots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [canShowUser, setCanShowUser] = useState(false);

  const load = useCallback(async () => {
    try {
      const [list, spots] = await Promise.all([
        api.listReports({ limit: 200, status: filter === 'active' ? 'active' : undefined }),
        api.hotspots(),
      ]);
      setReports(list.reports);
      setHotspots(spots.hotspots);
      setError(null);

      if (!fitted.current && list.reports.length > 0) {
        fitted.current = true;
        setTimeout(() => {
          const coords = list.reports.map((r) => ({ latitude: r.latitude, longitude: r.longitude }));
          if (coords.length === 1) {
            mapRef.current?.animateToRegion({ ...coords[0], latitudeDelta: 0.02, longitudeDelta: 0.02 }, 400);
          } else {
            mapRef.current?.fitToCoordinates(coords, {
              edgePadding: { top: 100, right: 60, bottom: 120, left: 60 },
              animated: true,
            });
          }
        }, 300);
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const centerOnMe = async () => {
    const permission = await Location.requestForegroundPermissionsAsync();
    if (permission.status !== 'granted') return;
    setCanShowUser(true);
    try {
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      mapRef.current?.animateToRegion(
        { latitude: position.coords.latitude, longitude: position.coords.longitude, latitudeDelta: 0.02, longitudeDelta: 0.02 },
        500
      );
    } catch {
      // No position available; the map simply stays where it is.
    }
  };

  return (
    <Screen edges={['top']}>
      <View style={styles.wrapper}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          initialRegion={DEFAULT_REGION}
          showsUserLocation={canShowUser}
          showsMyLocationButton={false}
        >
          {hotspots.map((h, index) => (
            <Circle
              key={`hotspot-${index}`}
              center={{ latitude: h.latitude, longitude: h.longitude }}
              radius={Math.max(h.radius_m, 60)}
              strokeColor={risk[h.risk_level].color}
              strokeWidth={2}
              fillColor={`${risk[h.risk_level].color}33`}
            />
          ))}
          {reports.map((r) => (
            <Marker
              key={r.id}
              coordinate={{ latitude: r.latitude, longitude: r.longitude }}
              pinColor={r.status === 'resolved' ? colors.muted : risk[r.risk_level].color}
            >
              <Callout onPress={() => navigation.navigate('ReportDetail', { id: r.id })}>
                <View style={styles.callout}>
                  <Text style={styles.calloutTitle}>{reportTitle(r)}</Text>
                  <Text style={type.small}>
                    {r.status === 'resolved' ? 'Resolved' : risk[r.risk_level].label} · tap for details
                  </Text>
                </View>
              </Callout>
            </Marker>
          ))}
        </MapView>

        <View style={styles.topBar}>
          <Chip label="Active spots" active={filter === 'active'} onPress={() => { fitted.current = false; setFilter('active'); }} />
          <Chip label="Include resolved" active={filter === 'all'} onPress={() => { fitted.current = false; setFilter('all'); }} />
        </View>

        <Pressable accessibilityLabel="Centre on my location" onPress={centerOnMe} style={styles.locate}>
          <Ionicons name="locate" size={24} color={colors.pond} />
        </Pressable>

        <View style={styles.legend}>
          {['high', 'medium', 'low'].map((level) => (
            <View key={level} style={styles.legendItem}>
              <View style={[styles.dot, { backgroundColor: risk[level].color }]} />
              <Text style={styles.legendText}>{level.charAt(0).toUpperCase() + level.slice(1)}</Text>
            </View>
          ))}
          <View style={styles.legendItem}>
            <View style={[styles.ring, { borderColor: risk.high.color }]} />
            <Text style={styles.legendText}>Hotspot</Text>
          </View>
        </View>

        {loading ? (
          <View style={styles.overlay}>
            <Loading />
          </View>
        ) : error ? (
          <View style={styles.overlay}>
            <ErrorState message={error} onRetry={load} />
          </View>
        ) : null}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  wrapper: { flex: 1 },
  topBar: { position: 'absolute', top: space.md, left: space.md, flexDirection: 'row' },
  locate: {
    position: 'absolute',
    right: space.md,
    bottom: 76,
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.line,
  },
  legend: {
    position: 'absolute',
    left: space.md,
    right: space.md,
    bottom: space.md,
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    paddingVertical: space.md,
    borderWidth: 1,
    borderColor: colors.line,
  },
  legendItem: { flexDirection: 'row', alignItems: 'center' },
  legendText: { fontSize: 13, fontWeight: '600', color: colors.ink },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: 6 },
  ring: { width: 12, height: 12, borderRadius: 6, borderWidth: 2, marginRight: 6 },
  callout: { minWidth: 160, padding: 4 },
  calloutTitle: { fontSize: 15, fontWeight: '700', color: colors.ink },
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(242,246,245,0.92)', justifyContent: 'center' },
});
