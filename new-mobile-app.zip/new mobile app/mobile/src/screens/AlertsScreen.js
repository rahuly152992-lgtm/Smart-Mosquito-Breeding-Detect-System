import React, { useCallback, useState } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';

import ReportCard from '../components/ReportCard';
import { EmptyState, Screen } from '../components/ui';
import { useAlerts } from '../context/AlertsContext';
import { space, type } from '../theme';

export default function AlertsScreen({ navigation }) {
  const { alerts, refresh, markSeen } = useAlerts();
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(
    useCallback(() => {
      refresh();
      markSeen();
    }, [refresh, markSeen])
  );

  const pull = async () => {
    setRefreshing(true);
    await refresh();
    setRefreshing(false);
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={type.title}>Alerts</Text>
        <Text style={type.body}>High-risk spots that still need cleaning. This list updates every 30 seconds.</Text>
      </View>
      <FlatList
        data={alerts}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => (
          <ReportCard report={item} onPress={() => navigation.navigate('ReportDetail', { id: item.id })} />
        )}
        contentContainerStyle={styles.list}
        refreshing={refreshing}
        onRefresh={pull}
        ListEmptyComponent={
          <EmptyState
            icon="shield-checkmark-outline"
            title="All clear"
            message="No high-risk breeding spots are waiting to be cleaned."
          />
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: space.lg, paddingTop: space.lg },
  list: { padding: space.lg, paddingBottom: space.xxl },
});
