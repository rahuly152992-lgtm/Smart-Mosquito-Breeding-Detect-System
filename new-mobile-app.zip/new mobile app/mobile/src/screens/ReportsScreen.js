import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';

import * as api from '../api/client';
import ReportCard from '../components/ReportCard';
import { Chip, EmptyState, ErrorState, Loading, Screen } from '../components/ui';
import { colors, space, type } from '../theme';

const PAGE_SIZE = 20;
const STATUS_FILTERS = [
  { key: 'active', label: 'Active' },
  { key: 'resolved', label: 'Resolved' },
  { key: 'all', label: 'All' },
];
const RISK_FILTERS = [
  { key: 'all', label: 'Any risk' },
  { key: 'high', label: 'High' },
  { key: 'medium', label: 'Medium' },
  { key: 'low', label: 'Low' },
];

export default function ReportsScreen({ navigation }) {
  const [status, setStatus] = useState('active');
  const [riskFilter, setRiskFilter] = useState('all');
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const itemsRef = useRef([]);

  // Start from an empty list whenever a filter changes (declared before the fetch effect on purpose).
  useEffect(() => {
    itemsRef.current = [];
    setItems([]);
  }, [status, riskFilter]);

  const fetchPage = useCallback(
    async (mode) => {
      if (mode === 'more') setLoadingMore(true);
      else if (mode === 'pull') setRefreshing(true);
      else if (mode === 'initial') setLoading(true);
      try {
        const data = await api.listReports({
          status: status === 'all' ? undefined : status,
          risk: riskFilter === 'all' ? undefined : riskFilter,
          limit: PAGE_SIZE,
          offset: mode === 'more' ? itemsRef.current.length : 0,
        });
        const next = mode === 'more' ? [...itemsRef.current, ...data.reports] : data.reports;
        itemsRef.current = next;
        setItems(next);
        setTotal(data.total);
        setError(null);
      } catch (e) {
        setError(e.message);
      } finally {
        setLoading(false);
        setLoadingMore(false);
        setRefreshing(false);
      }
    },
    [status, riskFilter]
  );

  useFocusEffect(
    useCallback(() => {
      fetchPage(itemsRef.current.length ? 'silent' : 'initial');
    }, [fetchPage])
  );

  const loadMore = () => {
    if (!loadingMore && !loading && items.length < total) fetchPage('more');
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={type.title}>Reports</Text>
        <Text style={type.body}>{loading ? ' ' : `${total} ${total === 1 ? 'spot' : 'spots'}`}</Text>
      </View>
      <View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
          {STATUS_FILTERS.map((f) => (
            <Chip key={f.key} label={f.label} active={status === f.key} onPress={() => setStatus(f.key)} />
          ))}
        </ScrollView>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
          {RISK_FILTERS.map((f) => (
            <Chip key={f.key} label={f.label} active={riskFilter === f.key} onPress={() => setRiskFilter(f.key)} />
          ))}
        </ScrollView>
      </View>

      {loading ? (
        <Loading />
      ) : error && items.length === 0 ? (
        <ErrorState message={error} onRetry={() => fetchPage('initial')} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <ReportCard report={item} onPress={() => navigation.navigate('ReportDetail', { id: item.id })} />
          )}
          contentContainerStyle={styles.list}
          refreshing={refreshing}
          onRefresh={() => fetchPage('pull')}
          onEndReached={loadMore}
          onEndReachedThreshold={0.4}
          ListEmptyComponent={
            <EmptyState
              icon="search-outline"
              title="No spots match"
              message="Try another filter, or scan a place to add the first report."
            />
          }
          ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.pond} style={{ margin: space.lg }} /> : null}
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: space.lg, paddingTop: space.lg, marginBottom: space.md },
  chips: { paddingHorizontal: space.lg, paddingBottom: space.sm },
  list: { padding: space.lg, paddingBottom: space.xxl },
});
