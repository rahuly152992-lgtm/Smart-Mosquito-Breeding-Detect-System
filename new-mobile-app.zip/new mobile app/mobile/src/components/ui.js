import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';

import { colors, radius, risk, space, type } from '../theme';

export function Screen({ children, style, edges = ['top'] }) {
  return (
    <SafeAreaView edges={edges} style={[styles.screen, style]}>
      {children}
    </SafeAreaView>
  );
}

const buttonColors = {
  primary: { bg: colors.pond, fg: '#FFFFFF', border: colors.pond },
  secondary: { bg: colors.surface, fg: colors.pond, border: colors.pond },
  danger: { bg: colors.danger, fg: '#FFFFFF', border: colors.danger },
  ghost: { bg: 'transparent', fg: colors.pond, border: 'transparent' },
};

export function Button({ title, onPress, icon, variant = 'primary', loading = false, disabled = false, style }) {
  const palette = buttonColors[variant];
  const inactive = disabled || loading;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: inactive }}
      onPress={onPress}
      disabled={inactive}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: palette.bg, borderColor: palette.border, opacity: inactive ? 0.5 : pressed ? 0.85 : 1 },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={palette.fg} />
      ) : (
        <>
          {icon ? <Ionicons name={icon} size={19} color={palette.fg} style={styles.buttonIcon} /> : null}
          <Text style={[styles.buttonText, { color: palette.fg }]}>{title}</Text>
        </>
      )}
    </Pressable>
  );
}

export function Chip({ label, active, onPress }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: !!active }}
      onPress={onPress}
      style={[styles.chip, active && styles.chipActive]}
    >
      <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
    </Pressable>
  );
}

export function Card({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function SectionTitle({ children, right }) {
  return (
    <View style={styles.sectionRow}>
      <Text style={type.heading}>{children}</Text>
      {right}
    </View>
  );
}

export function RiskBadge({ level, score }) {
  const tone = risk[level] || risk.low;
  return (
    <View style={[styles.badge, { backgroundColor: tone.tint }]}>
      <View style={[styles.badgeDot, { backgroundColor: tone.color }]} />
      <Text style={[styles.badgeText, { color: tone.color }]}>
        {tone.label}
        {typeof score === 'number' ? ` · ${score}` : ''}
      </Text>
    </View>
  );
}

export function Banner({ tone = 'info', icon = 'information-circle', children }) {
  const palette = {
    info: { bg: colors.pondTint, fg: colors.pondDark },
    warn: { bg: risk.medium.tint, fg: risk.medium.color },
    good: { bg: risk.low.tint, fg: risk.low.color },
    bad: { bg: risk.high.tint, fg: risk.high.color },
  }[tone];
  return (
    <View style={[styles.banner, { backgroundColor: palette.bg }]}>
      <Ionicons name={icon} size={20} color={palette.fg} style={{ marginTop: 1 }} />
      <Text style={[styles.bannerText, { color: palette.fg }]}>{children}</Text>
    </View>
  );
}

export function Loading({ label }) {
  return (
    <View style={styles.center}>
      <ActivityIndicator size="large" color={colors.pond} />
      {label ? <Text style={[type.body, { marginTop: space.md }]}>{label}</Text> : null}
    </View>
  );
}

export function EmptyState({ icon = 'leaf-outline', title, message, action }) {
  return (
    <View style={styles.center}>
      <Ionicons name={icon} size={40} color={colors.muted} />
      <Text style={[type.heading, styles.centerText]}>{title}</Text>
      {message ? <Text style={[type.body, styles.centerText]}>{message}</Text> : null}
      {action ? <View style={{ marginTop: space.lg }}>{action}</View> : null}
    </View>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <EmptyState
      icon="cloud-offline-outline"
      title="Something went wrong"
      message={message}
      action={onRetry ? <Button title="Try again" variant="secondary" onPress={onRetry} /> : null}
    />
  );
}

export function Field({ label, style, ...inputProps }) {
  return (
    <View style={[{ marginBottom: space.lg }, style]}>
      {label ? <Text style={styles.fieldLabel}>{label}</Text> : null}
      <TextInput
        placeholderTextColor="#8A9A9F"
        autoCapitalize="none"
        style={[styles.input, inputProps.multiline && styles.inputMultiline]}
        {...inputProps}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.mist },
  button: {
    minHeight: 50,
    borderRadius: radius.md,
    borderWidth: 1.5,
    paddingHorizontal: space.lg,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonIcon: { marginRight: space.sm },
  buttonText: { fontSize: 16, fontWeight: '700' },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.surface,
    marginRight: space.sm,
  },
  chipActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  chipText: { fontSize: 14, fontWeight: '600', color: colors.ink },
  chipTextActive: { color: '#FFFFFF' },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: space.lg,
    borderWidth: 1,
    borderColor: colors.line,
  },
  sectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: space.xl,
    marginBottom: space.md,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radius.pill,
  },
  badgeDot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  badgeText: { fontSize: 13, fontWeight: '700' },
  banner: { flexDirection: 'row', padding: space.md, borderRadius: radius.md, marginBottom: space.lg },
  bannerText: { flex: 1, marginLeft: space.sm, fontSize: 14, lineHeight: 20, fontWeight: '500' },
  center: { alignItems: 'center', justifyContent: 'center', padding: space.xxl },
  centerText: { textAlign: 'center', marginTop: space.sm },
  fieldLabel: { fontSize: 14, fontWeight: '600', color: colors.ink, marginBottom: 6 },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radius.md,
    paddingHorizontal: space.md,
    paddingVertical: 13,
    fontSize: 16,
    color: colors.ink,
  },
  inputMultiline: { minHeight: 84, textAlignVertical: 'top' },
});
