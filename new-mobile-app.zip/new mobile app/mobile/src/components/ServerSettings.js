import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import * as api from '../api/client';
import { useAuth } from '../context/AuthContext';
import { colors, space, type } from '../theme';
import { Banner, Button, Field } from './ui';

// Lets the person point the app at their backend (needed because a phone cannot use "localhost").
export default function ServerSettings() {
  const { serverUrl, setServer } = useAuth();
  const [draft, setDraft] = useState(serverUrl);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);

  const saveAndTest = async () => {
    setBusy(true);
    setResult(null);
    await setServer(draft);
    try {
      const status = await api.health();
      const detector = status.detector || {};
      let text = 'Connected to the server.';
      if (detector.active_mode === 'loading') text += ' The AI model is still loading.';
      else if (detector.simulated) text += ' It is running demo detection (no trained model loaded).';
      else text += ` AI model ready (${detector.model}).`;
      setResult({ tone: detector.simulated ? 'warn' : 'good', text });
    } catch (e) {
      setResult({ tone: 'bad', text: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <View>
      <Field
        label="Server address"
        value={draft}
        onChangeText={setDraft}
        placeholder="http://192.168.1.20:5000"
        keyboardType="url"
        autoCorrect={false}
        style={{ marginBottom: space.md }}
      />
      <Text style={[type.small, styles.hint]}>
        On a real phone use your computer's Wi-Fi address. The Android emulator uses http://10.0.2.2:5000.
      </Text>
      {result ? (
        <Banner tone={result.tone} icon={result.tone === 'bad' ? 'alert-circle' : 'checkmark-circle'}>
          {result.text}
        </Banner>
      ) : null}
      <Button title="Save and test connection" variant="secondary" onPress={saveAndTest} loading={busy} />
    </View>
  );
}

const styles = StyleSheet.create({
  hint: { color: colors.muted, marginBottom: space.md },
});
