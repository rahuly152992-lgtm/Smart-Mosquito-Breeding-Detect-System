import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { colors, space, type } from '../theme';

// Small grouped bar chart drawn with plain views (no chart library needed).
// data: [{ label, a, b }]  -  a and b are the two series for each day.
export default function BarChart({ data, colorA, colorB, height = 120 }) {
  const max = Math.max(1, ...data.flatMap((d) => [d.a, d.b]));
  const bar = (value, color) => (
    <View style={styles.barSlot}>
      <Text style={styles.value}>{value > 0 ? value : ''}</Text>
      <View style={[styles.bar, { height: Math.max(value > 0 ? 4 : 0, (value / max) * height), backgroundColor: color }]} />
    </View>
  );
  return (
    <View>
      <View style={[styles.row, { height: height + 20 }]}>
        {data.map((d) => (
          <View key={d.label} style={styles.group}>
            <View style={styles.bars}>
              {bar(d.a, colorA)}
              {bar(d.b, colorB)}
            </View>
          </View>
        ))}
      </View>
      <View style={styles.axis} />
      <View style={styles.row}>
        {data.map((d) => (
          <Text key={d.label} style={styles.label}>
            {d.label}
          </Text>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'flex-end' },
  group: { flex: 1, alignItems: 'center' },
  bars: { flexDirection: 'row', alignItems: 'flex-end' },
  barSlot: { alignItems: 'center', justifyContent: 'flex-end', width: 14, marginHorizontal: 1 },
  bar: { width: 12, borderTopLeftRadius: 4, borderTopRightRadius: 4 },
  value: { fontSize: 10, color: colors.muted, marginBottom: 2 },
  axis: { height: 1, backgroundColor: colors.line, marginTop: 2, marginBottom: space.xs },
  label: { flex: 1, textAlign: 'center', ...type.small, fontSize: 12 },
});
