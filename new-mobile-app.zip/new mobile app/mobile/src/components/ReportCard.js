import React from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { assetUrl } from '../api/client';
import { colors, radius, risk, space, type } from '../theme';
import { placeText, reportTitle, timeAgo } from '../utils/format';
import { RiskBadge } from './ui';

export default function ReportCard({ report, onPress }) {
  const tone = report.status === 'resolved' ? colors.muted : (risk[report.risk_level] || risk.low).color;
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.card, { borderLeftColor: tone, opacity: pressed ? 0.9 : 1 }]}
    >
      <Image source={{ uri: assetUrl(report.image_url) }} style={styles.thumb} />
      <View style={styles.body}>
        <Text style={styles.title} numberOfLines={1}>
          {reportTitle(report)}
        </Text>
        <Text style={type.small} numberOfLines={1}>
          {placeText(report)}
        </Text>
        <View style={styles.meta}>
          {report.status === 'resolved' ? (
            <View style={styles.resolved}>
              <Ionicons name="checkmark-circle" size={16} color={colors.muted} />
              <Text style={styles.resolvedText}>Resolved</Text>
            </View>
          ) : (
            <RiskBadge level={report.risk_level} />
          )}
          <Text style={[type.small, { marginLeft: space.sm }]}>{timeAgo(report.created_at)}</Text>
        </View>
      </View>
      <Ionicons name="chevron-forward" size={20} color={colors.muted} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.line,
    borderLeftWidth: 5,
    padding: space.md,
    marginBottom: space.md,
  },
  thumb: { width: 64, height: 64, borderRadius: radius.sm, backgroundColor: colors.line },
  body: { flex: 1, marginHorizontal: space.md },
  title: { fontSize: 16, fontWeight: '700', color: colors.ink, marginBottom: 2 },
  meta: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  resolved: { flexDirection: 'row', alignItems: 'center' },
  resolvedText: { marginLeft: 4, fontSize: 13, fontWeight: '700', color: colors.muted },
});
