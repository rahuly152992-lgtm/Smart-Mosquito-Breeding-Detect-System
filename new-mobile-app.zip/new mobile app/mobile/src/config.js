// The backend address. Overridable at runtime from the sign-in screen or Settings.
export const DEFAULT_API_URL = (process.env.EXPO_PUBLIC_API_URL || 'http://10.0.2.2:5000').replace(/\/+$/, '');

// How often the app checks the server for new high-risk spots (milliseconds).
export const ALERT_POLL_MS = 30000;

// Map region used before any spot or GPS position is known (whole-country view).
export const DEFAULT_REGION = { latitude: 20.5937, longitude: 78.9629, latitudeDelta: 25, longitudeDelta: 25 };
