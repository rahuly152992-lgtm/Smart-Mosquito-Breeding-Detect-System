// Design tokens. Colour carries meaning: teal = the app, red/amber/green = mosquito risk.
export const colors = {
  ink: '#14232B',
  pond: '#0F6E7A',
  pondDark: '#0B525B',
  pondTint: '#DDEDEE',
  mist: '#F2F6F5',
  surface: '#FFFFFF',
  line: '#DCE5E3',
  muted: '#5D6F75',
  danger: '#C7352B',
};

export const risk = {
  high: { color: '#C7352B', tint: '#FBE9E7', label: 'High risk' },
  medium: { color: '#B77400', tint: '#FCF1DB', label: 'Medium risk' },
  low: { color: '#3F8F5B', tint: '#E4F2E9', label: 'Low risk' },
};

export const radius = { sm: 8, md: 12, lg: 20, pill: 999 };
export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 };

export const type = {
  title: { fontSize: 26, fontWeight: '800', color: colors.ink, letterSpacing: -0.4 },
  heading: { fontSize: 18, fontWeight: '700', color: colors.ink },
  body: { fontSize: 15, lineHeight: 22, color: colors.muted },
  bodyStrong: { fontSize: 15, lineHeight: 22, color: colors.ink, fontWeight: '600' },
  small: { fontSize: 13, lineHeight: 18, color: colors.muted },
};
