import { useCallback, useRef, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';

// Loads data every time the screen comes into focus and supports pull-to-refresh.
export function useFocusFetch(loader) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const loaderRef = useRef(loader);
  loaderRef.current = loader;

  const run = useCallback(async (pull = false) => {
    if (pull) setRefreshing(true);
    try {
      setData(await loaderRef.current());
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      run();
    }, [run])
  );

  const refresh = useCallback(() => run(true), [run]);
  const reload = useCallback(() => {
    setLoading(true);
    return run();
  }, [run]);

  return { data, error, loading, refreshing, refresh, reload };
}
