// All communication with the Flask backend lives here.
import { DEFAULT_API_URL } from '../config';

export class ApiError extends Error {
  constructor(message, status = 0) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

let baseUrl = DEFAULT_API_URL;
let authToken = null;
let onUnauthorized = null;

export function normalizeUrl(url) {
  let value = (url || '').trim().replace(/\/+$/, '');
  if (value && !/^https?:\/\//i.test(value)) value = `http://${value}`;
  return value;
}

export const setBaseUrl = (url) => {
  baseUrl = normalizeUrl(url) || DEFAULT_API_URL;
};
export const getBaseUrl = () => baseUrl;
export const setToken = (token) => {
  authToken = token;
};
export const setUnauthorizedHandler = (handler) => {
  onUnauthorized = handler;
};

// Turns "/uploads/abc.jpg" from the API into a full URL the <Image> component can load.
export const assetUrl = (path) => {
  if (!path) return null;
  return /^https?:\/\//i.test(path) ? path : `${baseUrl}${path}`;
};

async function request(path, { method = 'GET', body, form, timeout = 20000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  const headers = { Accept: 'application/json' };
  if (authToken) headers.Authorization = `Bearer ${authToken}`;

  let payload;
  if (form) {
    payload = form; // fetch sets the multipart boundary itself
  } else if (body) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }

  try {
    const response = await fetch(`${baseUrl}/api${path}`, { method, headers, body: payload, signal: controller.signal });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      if (response.status === 401 && authToken && onUnauthorized) onUnauthorized();
      throw new ApiError(data.error || `The server returned an error (${response.status}).`, response.status);
    }
    return data;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    if (err.name === 'AbortError') {
      throw new ApiError('The server took too long to respond. Check the server address in Settings.');
    }
    throw new ApiError('Cannot reach the server. Make sure the backend is running and the server address is correct.');
  } finally {
    clearTimeout(timer);
  }
}

const query = (params = {}) => {
  const pairs = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '');
  return pairs.length ? `?${pairs.map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&')}` : '';
};

const photoPart = (uri, name) => ({ uri, name, type: 'image/jpeg' });

// --- Auth -------------------------------------------------------------------
export const health = () => request('/health', { timeout: 8000 });
export const login = (email, password) => request('/auth/login', { method: 'POST', body: { email, password } });
export const register = (name, email, password) =>
  request('/auth/register', { method: 'POST', body: { name, email, password } });
export const me = () => request('/auth/me');

// --- Reports ----------------------------------------------------------------
export function createReport({ uri, latitude, longitude, address, notes, waterPresent, saveIfClean }) {
  const form = new FormData();
  form.append('image', photoPart(uri, 'spot.jpg'));
  form.append('latitude', String(latitude));
  form.append('longitude', String(longitude));
  if (address) form.append('address', address);
  if (notes) form.append('notes', notes);
  form.append('water_present', waterPresent ? 'true' : 'false');
  form.append('save_if_clean', saveIfClean ? 'true' : 'false');
  return request('/reports', { method: 'POST', form, timeout: 90000 }); // AI analysis can be slow on a CPU
}

export const listReports = (params) => request(`/reports${query(params)}`);
export const getReport = (id) => request(`/reports/${id}`);
export const reopenReport = (id) => request(`/reports/${id}/reopen`, { method: 'POST' });

export function resolveReport(id, { note, uri }) {
  if (uri) {
    const form = new FormData();
    form.append('note', note || '');
    form.append('image', photoPart(uri, 'cleaned.jpg'));
    return request(`/reports/${id}/resolve`, { method: 'POST', form, timeout: 60000 });
  }
  return request(`/reports/${id}/resolve`, { method: 'POST', body: { note: note || '' } });
}

// --- Insights ---------------------------------------------------------------
export const summary = () => request('/stats/summary');
export const weekly = (weeksAgo = 0) => request(`/stats/weekly${query({ weeks_ago: weeksAgo })}`);
export const hotspots = () => request('/hotspots');
export const alerts = () => request('/alerts');
