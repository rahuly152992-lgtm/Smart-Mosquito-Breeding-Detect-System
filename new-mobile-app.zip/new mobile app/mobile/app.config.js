// Expo app configuration. Values that differ per machine come from environment variables.
const googleMapsKey = process.env.GOOGLE_MAPS_API_KEY; // only needed for release builds on Android

module.exports = {
  expo: {
    name: 'MosquitoWatch',
    slug: 'mosquito-watch',
    version: '1.0.0',
    orientation: 'portrait',
    icon: './assets/icon.png',
    userInterfaceStyle: 'light',
    scheme: 'mosquitowatch',
    ios: {
      supportsTablet: false,
      bundleIdentifier: 'com.mosquitowatch.app',
      infoPlist: {
        // The backend runs on a local network address over plain HTTP during development.
        NSAppTransportSecurity: { NSAllowsArbitraryLoads: true },
      },
    },
    android: {
      package: 'com.mosquitowatch.app',
      adaptiveIcon: {
        foregroundImage: './assets/adaptive-icon.png',
        backgroundColor: '#0F6E7A',
      },
      permissions: ['CAMERA', 'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION'],
      ...(googleMapsKey ? { config: { googleMaps: { apiKey: googleMapsKey } } } : {}),
    },
    plugins: [
      ['expo-build-properties', { android: { usesCleartextTraffic: true } }],
      [
        'expo-image-picker',
        {
          cameraPermission: 'MosquitoWatch uses the camera to photograph possible breeding spots.',
          photosPermission: 'MosquitoWatch reads photos you choose to report as breeding spots.',
        },
      ],
      [
        'expo-location',
        { locationWhenInUsePermission: 'MosquitoWatch uses your location to place a breeding spot on the map.' },
      ],
    ],
  },
};
