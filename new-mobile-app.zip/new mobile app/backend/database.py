"""SQLite helpers. SQLite needs no setup, which keeps the project easy to run."""
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from flask import current_app, g

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reports (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             INTEGER REFERENCES users(id) ON DELETE SET NULL,
    source              TEXT NOT NULL DEFAULT 'mobile',
    latitude            REAL NOT NULL,
    longitude           REAL NOT NULL,
    address             TEXT,
    notes               TEXT,
    water_present       INTEGER NOT NULL DEFAULT 0,
    image_file          TEXT NOT NULL,
    annotated_file      TEXT,
    detections          TEXT NOT NULL DEFAULT '[]',
    risk_level          TEXT NOT NULL,
    risk_score          INTEGER NOT NULL,
    simulated           INTEGER NOT NULL DEFAULT 0,
    status              TEXT NOT NULL DEFAULT 'active',
    created_at          TEXT NOT NULL,
    resolved_at         TEXT,
    resolved_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    resolution_note     TEXT,
    resolved_image_file TEXT
);

CREATE INDEX IF NOT EXISTS idx_reports_status  ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_risk    ON reports(risk_level);
CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at);
"""


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def get_db():
    if "db" not in g:
        conn = sqlite3.connect(current_app.config["DATABASE_PATH"])
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        g.db = conn
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db(app):
    path = Path(app.config["DATABASE_PATH"])
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()
    app.teardown_appcontext(close_db)
