"""Token authentication for the mobile app and API-key auth for ESP32 devices."""
import hmac
import re
from functools import wraps

from flask import current_app, g, jsonify, request
from itsdangerous import BadSignature, URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash

from database import get_db

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def hash_password(password):
    return generate_password_hash(password)


def verify_password(password_hash, password):
    return check_password_hash(password_hash, password)


def _serializer():
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt="mosquito-auth")


def create_token(user_id):
    return _serializer().dumps({"uid": user_id})


def user_to_dict(row):
    return {"id": row["id"], "name": row["name"], "email": row["email"], "created_at": row["created_at"]}


def _user_from_token():
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    try:
        data = _serializer().loads(header[7:], max_age=current_app.config["TOKEN_MAX_AGE_SECONDS"])
    except BadSignature:
        return None
    return get_db().execute(
        "SELECT id, name, email, created_at FROM users WHERE id = ?", (data.get("uid"),)
    ).fetchone()


def _valid_device_key():
    supplied = request.headers.get("X-Device-Key", "")
    if not supplied:
        return False
    return any(hmac.compare_digest(supplied, key) for key in current_app.config["DEVICE_API_KEYS"])


def _unauthorized():
    return jsonify({"error": "Please sign in again."}), 401


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        user = _user_from_token()
        if user is None:
            return _unauthorized()
        g.user = user
        g.device = False
        return view(*args, **kwargs)

    return wrapper


def auth_or_device_required(view):
    """Accept either a signed-in user or an ESP32 with a valid X-Device-Key."""

    @wraps(view)
    def wrapper(*args, **kwargs):
        user = _user_from_token()
        if user is not None:
            g.user, g.device = user, False
        elif _valid_device_key():
            g.user, g.device = None, True
        else:
            return _unauthorized()
        return view(*args, **kwargs)

    return wrapper
