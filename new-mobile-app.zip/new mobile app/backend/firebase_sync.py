"""Optional one-way sync of reports to Firebase Firestore.

Enabled only when FIREBASE_CREDENTIALS points to a service-account JSON file and the
`firebase-admin` package is installed. If either is missing the app simply runs on
SQLite - nothing else changes.
"""
import logging
import threading

log = logging.getLogger(__name__)

_client = None
_collection = "breeding_spots"


def init(credentials_path, collection="breeding_spots"):
    global _client, _collection
    _collection = collection
    if not credentials_path:
        return False
    try:
        import firebase_admin
        from firebase_admin import credentials, firestore

        if not firebase_admin._apps:
            firebase_admin.initialize_app(credentials.Certificate(credentials_path))
        _client = firestore.client()
        log.info("Firebase sync enabled (collection: %s)", collection)
        return True
    except Exception as exc:  # noqa: BLE001
        log.warning("Firebase sync disabled: %s", exc)
        _client = None
        return False


def enabled():
    return _client is not None


def push_report(report):
    """Copy a serialised report to Firestore in the background."""
    if _client is None:
        return
    document = {k: v for k, v in report.items() if k != "advice"}

    def _write():
        try:
            _client.collection(_collection).document(str(report["id"])).set(document)
        except Exception as exc:  # noqa: BLE001
            log.warning("Firebase write failed for report %s: %s", report["id"], exc)

    threading.Thread(target=_write, daemon=True).start()
