"""REST API used by the mobile app (and by ESP32 cameras)."""
import json
import math
import sqlite3
import uuid
from datetime import datetime, time, timedelta, timezone
from pathlib import Path

import cv2
import numpy as np
from flask import Blueprint, current_app, g, jsonify, request

import firebase_sync
from auth import (
    EMAIL_RE, auth_or_device_required, create_token, hash_password,
    login_required, user_to_dict, verify_password,
)
from database import get_db, utc_now
from detector import DetectorUnavailable, annotate
from risk import advice_for, assess

api = Blueprint("api", __name__)

RISK_LEVELS = ("low", "medium", "high")
STATUSES = ("active", "resolved")
MAX_IMAGE_SIDE = 1280
REPORT_SELECT = (
    "SELECT r.*, u.name AS reporter_name FROM reports r "
    "LEFT JOIN users u ON u.id = r.user_id"
)


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def error(message, status=400):
    return jsonify({"error": message}), status


def truthy(value):
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def clean(value, limit):
    return (value or "").strip()[:limit]


def int_arg(name, default, low, high):
    try:
        value = int(request.args.get(name, default))
    except (TypeError, ValueError):
        return default
    return max(low, min(high, value))


def decode_image(data):
    if not data:
        return None
    return cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)


def shrink(image):
    height, width = image.shape[:2]
    longest = max(height, width)
    if longest <= MAX_IMAGE_SIDE:
        return image
    ratio = MAX_IMAGE_SIDE / longest
    return cv2.resize(image, (int(width * ratio), int(height * ratio)), interpolation=cv2.INTER_AREA)


def save_image(image):
    name = f"{uuid.uuid4().hex}.jpg"
    path = Path(current_app.config["UPLOAD_DIR"]) / name
    if not cv2.imwrite(str(path), image, [int(cv2.IMWRITE_JPEG_QUALITY), 88]):
        raise OSError("Could not save the image")
    return name


def read_upload(field="image"):
    """Return (image, error_response). Exactly one of them is None."""
    file = request.files.get(field)
    if file is None:
        return None, error("Attach a photo in the 'image' field.")
    image = decode_image(file.read())
    if image is None:
        return None, error("The uploaded file is not a valid image.")
    return shrink(image), None


def upload_url(name):
    return f"/uploads/{name}" if name else None


def report_to_dict(row):
    detections = json.loads(row["detections"] or "[]")
    labels = sorted({d["label"] for d in detections})
    return {
        "id": row["id"],
        "source": row["source"],
        "latitude": row["latitude"],
        "longitude": row["longitude"],
        "address": row["address"],
        "notes": row["notes"],
        "water_present": bool(row["water_present"]),
        "image_url": upload_url(row["annotated_file"] or row["image_file"]),
        "original_image_url": upload_url(row["image_file"]),
        "detections": detections,
        "labels": labels,
        "risk_level": row["risk_level"],
        "risk_score": row["risk_score"],
        "simulated": bool(row["simulated"]),
        "status": row["status"],
        "created_at": row["created_at"],
        "resolved_at": row["resolved_at"],
        "resolution_note": row["resolution_note"],
        "resolved_image_url": upload_url(row["resolved_image_file"]),
        "reporter": row["reporter_name"] if "reporter_name" in row.keys() else None,
        "advice": advice_for(row["risk_level"], labels),
    }


def fetch_report(report_id):
    return get_db().execute(f"{REPORT_SELECT} WHERE r.id = ?", (report_id,)).fetchone()


def local_offset():
    return timedelta(minutes=current_app.config["LOCAL_UTC_OFFSET_MINUTES"])


def local_day_start_utc(day):
    """UTC timestamp of local midnight at the start of `day`."""
    return datetime.combine(day, time.min, tzinfo=timezone.utc) - local_offset()


def iso(dt):
    return dt.isoformat(timespec="seconds")


# --------------------------------------------------------------------------
# Auth
# --------------------------------------------------------------------------
@api.post("/auth/register")
def register():
    data = request.get_json(silent=True) or {}
    name = clean(data.get("name"), 60)
    email = clean(data.get("email"), 120).lower()
    password = data.get("password") or ""
    if len(name) < 2:
        return error("Enter your name (at least 2 characters).")
    if not EMAIL_RE.match(email):
        return error("Enter a valid email address.")
    if len(password) < 6:
        return error("Choose a password with at least 6 characters.")
    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
            (name, email, hash_password(password), utc_now()),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return error("An account with this email already exists.", 409)
    user = db.execute("SELECT * FROM users WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify({"token": create_token(user["id"]), "user": user_to_dict(user)}), 201


@api.post("/auth/login")
def login():
    data = request.get_json(silent=True) or {}
    email = clean(data.get("email"), 120).lower()
    password = data.get("password") or ""
    user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if user is None or not verify_password(user["password_hash"], password):
        return error("Email or password is incorrect.", 401)
    return jsonify({"token": create_token(user["id"]), "user": user_to_dict(user)})


@api.get("/auth/me")
@login_required
def me():
    return jsonify({"user": user_to_dict(g.user)})


# --------------------------------------------------------------------------
# Reports
# --------------------------------------------------------------------------
@api.post("/reports")
@auth_or_device_required
def create_report():
    """Analyse a photo and (usually) save it as a breeding-spot report.

    Multipart fields: image, latitude, longitude, address, notes, water_present,
    save_if_clean. When nothing is detected the report is *not* saved unless
    `save_if_clean` is true or the person reported visible standing water.
    """
    try:
        latitude = float(request.form["latitude"])
        longitude = float(request.form["longitude"])
    except (KeyError, ValueError):
        return error("latitude and longitude are required and must be numbers.")
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        return error("latitude or longitude is out of range.")

    image, problem = read_upload("image")
    if problem:
        return problem

    water_present = truthy(request.form.get("water_present"))
    try:
        detections, simulated = current_app.extensions["detector"].detect(image)
    except DetectorUnavailable as exc:
        return error(f"The detection model is not available: {exc}", 503)

    score, level = assess(detections, water_present)
    labels = sorted({d["label"] for d in detections})
    analysis = {
        "detections": detections,
        "labels": labels,
        "risk_level": level,
        "risk_score": score,
        "simulated": simulated,
        "water_present": water_present,
    }

    if not detections and not water_present and not truthy(request.form.get("save_if_clean")):
        return jsonify({"saved": False, "analysis": analysis}), 200

    image_file = save_image(image)
    annotated_file = save_image(annotate(image, detections)) if detections else None
    db = get_db()
    cur = db.execute(
        """INSERT INTO reports (user_id, source, latitude, longitude, address, notes, water_present,
               image_file, annotated_file, detections, risk_level, risk_score, simulated, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)""",
        (
            g.user["id"] if g.user is not None else None,
            "esp32" if g.device else "mobile",
            latitude, longitude,
            clean(request.form.get("address"), 200),
            clean(request.form.get("notes"), 500),
            int(water_present),
            image_file, annotated_file,
            json.dumps(detections), level, score, int(simulated), utc_now(),
        ),
    )
    db.commit()
    report = report_to_dict(fetch_report(cur.lastrowid))
    firebase_sync.push_report(report)
    return jsonify({"saved": True, "report": report, "analysis": analysis}), 201


@api.get("/reports")
@login_required
def list_reports():
    where, params = [], []
    status = request.args.get("status")
    if status in STATUSES:
        where.append("r.status = ?")
        params.append(status)
    risk = request.args.get("risk")
    if risk in RISK_LEVELS:
        where.append("r.risk_level = ?")
        params.append(risk)
    if truthy(request.args.get("mine", "0")):
        where.append("r.user_id = ?")
        params.append(g.user["id"])
    clause = f" WHERE {' AND '.join(where)}" if where else ""
    limit = int_arg("limit", 30, 1, 200)
    offset = int_arg("offset", 0, 0, 10**9)

    db = get_db()
    total = db.execute(f"SELECT COUNT(*) FROM reports r{clause}", params).fetchone()[0]
    rows = db.execute(
        f"{REPORT_SELECT}{clause} ORDER BY r.created_at DESC, r.id DESC LIMIT ? OFFSET ?",
        [*params, limit, offset],
    ).fetchall()
    return jsonify({"reports": [report_to_dict(r) for r in rows], "total": total})


@api.get("/reports/<int:report_id>")
@login_required
def get_report(report_id):
    row = fetch_report(report_id)
    if row is None:
        return error("This report no longer exists.", 404)
    return jsonify({"report": report_to_dict(row)})


@api.post("/reports/<int:report_id>/resolve")
@login_required
def resolve_report(report_id):
    row = fetch_report(report_id)
    if row is None:
        return error("This report no longer exists.", 404)
    if row["status"] == "resolved":
        return error("This spot is already marked as resolved.", 409)

    payload = request.get_json(silent=True) or request.form
    note = clean(payload.get("note"), 500)
    resolved_file = None
    if "image" in request.files:
        image, problem = read_upload("image")
        if problem:
            return problem
        resolved_file = save_image(image)

    db = get_db()
    db.execute(
        """UPDATE reports SET status = 'resolved', resolved_at = ?, resolved_by = ?,
               resolution_note = ?, resolved_image_file = ? WHERE id = ?""",
        (utc_now(), g.user["id"], note, resolved_file, report_id),
    )
    db.commit()
    report = report_to_dict(fetch_report(report_id))
    firebase_sync.push_report(report)
    return jsonify({"report": report})


@api.post("/reports/<int:report_id>/reopen")
@login_required
def reopen_report(report_id):
    row = fetch_report(report_id)
    if row is None:
        return error("This report no longer exists.", 404)
    if row["status"] == "active":
        return error("This spot is already active.", 409)
    db = get_db()
    db.execute(
        """UPDATE reports SET status = 'active', resolved_at = NULL, resolved_by = NULL,
               resolution_note = NULL, resolved_image_file = NULL WHERE id = ?""",
        (report_id,),
    )
    db.commit()
    report = report_to_dict(fetch_report(report_id))
    firebase_sync.push_report(report)
    return jsonify({"report": report})


# --------------------------------------------------------------------------
# Hotspots, alerts and statistics
# --------------------------------------------------------------------------
def compute_hotspots(rows, grid_meters, min_reports):
    """Group active reports into a grid; cells with several reports are hotspots."""
    cell_lat = grid_meters / 111_320
    cells = {}
    for row in rows:
        cell_lng = grid_meters / (111_320 * max(0.2, math.cos(math.radians(row["latitude"]))))
        key = (math.floor(row["latitude"] / cell_lat), math.floor(row["longitude"] / cell_lng))
        cells.setdefault(key, []).append(row)

    hotspots = []
    for items in cells.values():
        if len(items) < min_reports:
            continue
        lat = sum(i["latitude"] for i in items) / len(items)
        lng = sum(i["longitude"] for i in items) / len(items)
        scale = 111_320 * max(0.2, math.cos(math.radians(lat)))
        radius = max(
            grid_meters / 2,
            max(math.hypot((i["longitude"] - lng) * scale, (i["latitude"] - lat) * 111_320) for i in items),
        )
        high = sum(1 for i in items if i["risk_level"] == "high")
        hotspots.append({
            "latitude": lat,
            "longitude": lng,
            "count": len(items),
            "high_count": high,
            "radius_m": round(radius),
            "risk_level": "high" if len(items) >= 4 or high >= 2 else "medium",
            "latest_at": max(i["created_at"] for i in items),
            "report_ids": [i["id"] for i in items],
        })
    hotspots.sort(key=lambda h: (h["count"], h["high_count"]), reverse=True)
    return hotspots


def active_hotspots():
    rows = get_db().execute(
        "SELECT id, latitude, longitude, risk_level, created_at FROM reports WHERE status = 'active'"
    ).fetchall()
    cfg = current_app.config
    return compute_hotspots(rows, cfg["HOTSPOT_GRID_METERS"], cfg["HOTSPOT_MIN_REPORTS"])


@api.get("/hotspots")
@login_required
def hotspots():
    return jsonify({"hotspots": active_hotspots()})


@api.get("/alerts")
@login_required
def alerts():
    """Active high-risk spots. The app polls this and passes the newest id it has seen."""
    after_id = int_arg("after_id", 0, 0, 10**12)
    db = get_db()
    rows = db.execute(
        f"{REPORT_SELECT} WHERE r.status = 'active' AND r.risk_level = 'high' AND r.id > ? "
        "ORDER BY r.id DESC LIMIT 50",
        (after_id,),
    ).fetchall()
    latest = db.execute("SELECT COALESCE(MAX(id), 0) FROM reports WHERE risk_level = 'high'").fetchone()[0]
    return jsonify({"alerts": [report_to_dict(r) for r in rows], "latest_id": latest})


@api.get("/stats/summary")
@login_required
def stats_summary():
    db = get_db()
    totals = db.execute(
        """SELECT COUNT(*) AS total,
                  COALESCE(SUM(status = 'active'), 0)   AS active,
                  COALESCE(SUM(status = 'resolved'), 0) AS resolved
           FROM reports"""
    ).fetchone()
    by_risk = {level: 0 for level in RISK_LEVELS}
    for row in db.execute(
        "SELECT risk_level, COUNT(*) AS n FROM reports WHERE status = 'active' GROUP BY risk_level"
    ):
        by_risk[row["risk_level"]] = row["n"]
    today_start = local_day_start_utc((datetime.now(timezone.utc) + local_offset()).date())
    today = db.execute("SELECT COUNT(*) FROM reports WHERE created_at >= ?", (iso(today_start),)).fetchone()[0]
    return jsonify({
        "total": totals["total"],
        "active": totals["active"],
        "resolved": totals["resolved"],
        "active_by_risk": by_risk,
        "new_today": today,
        "hotspot_count": len(active_hotspots()),
    })


@api.get("/stats/weekly")
@login_required
def stats_weekly():
    """Seven local days of activity. `weeks_ago=1` gives the previous week."""
    weeks_ago = int_arg("weeks_ago", 0, 0, 520)
    offset = local_offset()
    today = (datetime.now(timezone.utc) + offset).date()
    first_day = today - timedelta(days=6 + 7 * weeks_ago)
    last_day = first_day + timedelta(days=6)
    start = local_day_start_utc(first_day)
    end = start + timedelta(days=7)

    db = get_db()
    created = db.execute(
        f"{REPORT_SELECT} WHERE r.created_at >= ? AND r.created_at < ?", (iso(start), iso(end))
    ).fetchall()
    resolved = db.execute(
        "SELECT resolved_at FROM reports WHERE resolved_at >= ? AND resolved_at < ?", (iso(start), iso(end))
    ).fetchall()

    def local_day(value):
        return (datetime.fromisoformat(value) + offset).date()

    days = {first_day + timedelta(days=i): {"new": 0, "resolved": 0} for i in range(7)}
    by_risk = {level: 0 for level in RISK_LEVELS}
    by_type = {}
    for row in created:
        days[local_day(row["created_at"])]["new"] += 1
        by_risk[row["risk_level"]] += 1
        for label in {d["label"] for d in json.loads(row["detections"] or "[]")}:
            by_type[label] = by_type.get(label, 0) + 1
    for row in resolved:
        days[local_day(row["resolved_at"])]["resolved"] += 1

    return jsonify({
        "start": first_day.isoformat(),
        "end": last_day.isoformat(),
        "weeks_ago": weeks_ago,
        "new_reports": len(created),
        "resolved": len(resolved),
        "high_risk_new": by_risk["high"],
        "still_active": sum(1 for r in created if r["status"] == "active"),
        "by_risk": by_risk,
        "by_type": [{"label": k, "count": v} for k, v in sorted(by_type.items(), key=lambda kv: -kv[1])],
        "daily": [
            {"date": day.isoformat(), "weekday": day.strftime("%a"), **counts}
            for day, counts in sorted(days.items())
        ],
        "hotspots": active_hotspots()[:3] if weeks_ago == 0 else [],
    })
