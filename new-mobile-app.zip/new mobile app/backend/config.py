"""Central configuration. Every value can be overridden with an environment variable
or a `.env` file placed next to this file (see `.env.example`)."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _list(name):
    return [item.strip() for item in os.getenv(name, "").split(",") if item.strip()]


class Config:
    # --- Server -----------------------------------------------------------
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "5000"))
    DEBUG = os.getenv("FLASK_DEBUG", "0") == "1"
    SECRET_KEY = os.getenv("SECRET_KEY", "change-me-before-deploying")

    # --- Storage ----------------------------------------------------------
    DATABASE_PATH = os.getenv("DATABASE_PATH", str(BASE_DIR / "data" / "mosquito.db"))
    UPLOAD_DIR = os.getenv("UPLOAD_DIR", str(BASE_DIR / "uploads"))
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_UPLOAD_MB", "12")) * 1024 * 1024

    # --- Auth -------------------------------------------------------------
    TOKEN_MAX_AGE_SECONDS = int(os.getenv("TOKEN_MAX_AGE_DAYS", "30")) * 86400
    # Keys that ESP32 cameras send in the `X-Device-Key` header (comma separated).
    DEVICE_API_KEYS = _list("DEVICE_API_KEYS")

    # --- AI detection -----------------------------------------------------
    # auto : use YOLO if it can be loaded, otherwise fall back to simulated results
    # yolo : require YOLO (requests fail with 503 if it cannot be loaded)
    # mock : always return simulated results (UI demos / testing without a model)
    DETECTOR_MODE = os.getenv("DETECTOR_MODE", "auto").lower()
    YOLO_MODEL_PATH = os.getenv("YOLO_MODEL_PATH", str(BASE_DIR / "models" / "breeding_spots.pt"))
    DETECTION_CONFIDENCE = float(os.getenv("DETECTION_CONFIDENCE", "0.35"))
    WARM_UP_DETECTOR = os.getenv("WARM_UP_DETECTOR", "1") == "1"

    # --- Hotspots and reports ---------------------------------------------
    HOTSPOT_GRID_METERS = int(os.getenv("HOTSPOT_GRID_METERS", "200"))
    HOTSPOT_MIN_REPORTS = int(os.getenv("HOTSPOT_MIN_REPORTS", "2"))
    # Used to cut "days" for the weekly report. 330 = India Standard Time (UTC+5:30).
    LOCAL_UTC_OFFSET_MINUTES = int(os.getenv("LOCAL_UTC_OFFSET_MINUTES", "330"))

    # --- Optional Firebase sync ---------------------------------------------
    # Path to a Firebase service-account JSON file. Leave empty to disable.
    FIREBASE_CREDENTIALS = os.getenv("FIREBASE_CREDENTIALS", "")
    FIREBASE_COLLECTION = os.getenv("FIREBASE_COLLECTION", "breeding_spots")
