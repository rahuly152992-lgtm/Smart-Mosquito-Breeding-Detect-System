# Detection model

Put your trained YOLO weights here as **`breeding_spots.pt`** and set
`DETECTOR_MODE=auto` (or `yolo`) in `backend/.env`. The backend loads the file on start-up.

## Class names

The detector understands these class names (spaces, underscores and case are ignored):

| Class            | Also accepted                                    | Risk weight |
|------------------|--------------------------------------------------|-------------|
| `tyre`           | tire, old tyre                                   | 3           |
| `water_tank`     | tank, drum, barrel                               | 3           |
| `drain`          | open drain, clogged drain, gutter                | 3           |
| `puddle`         | stagnant water, standing water                   | 3           |
| `bucket`         | pail                                             | 2           |
| `flower_pot`     | plant pot, potted plant, vase                    | 2           |
| `container`      | cup, bowl, can, tub, coconut shell               | 2           |
| `plastic_bottle` | bottle                                           | 1           |

Any other class the model predicts (for example `person`) is ignored.

## Getting weights

1. Collect photos of these objects (phone photos of your own area work well, 200+ per class is a good start).
2. Label them in [Roboflow](https://roboflow.com), CVAT or Label Studio and export in **YOLOv8** format.
3. Edit `../train/dataset.yaml` so `path:` points at the exported dataset.
4. Train:  `python train/train_yolo.py --epochs 50`
   The best weights are copied to `models/breeding_spots.pt` automatically.

Without this file the backend loads generic COCO weights, which only know bottles, cups,
bowls, vases and potted plants. With no YOLO installed at all it returns clearly-labelled
simulated detections so the rest of the app can still be demonstrated.
