"""Smart Mosquito Breeding Spot Detection System - backend.

Run for development:   python app.py
Run in production:     gunicorn wsgi:app
"""
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, send_from_directory

import firebase_sync
from config import Config
from database import init_db
from detector import Detector
from routes import api


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    Path(app.config["UPLOAD_DIR"]).mkdir(parents=True, exist_ok=True)
    init_db(app)

    detector = Detector(
        mode=app.config["DETECTOR_MODE"],
        model_path=app.config["YOLO_MODEL_PATH"],
        confidence=app.config["DETECTION_CONFIDENCE"],
    )
    app.extensions["detector"] = detector
    if app.config["WARM_UP_DETECTOR"]:
        threading.Thread(target=detector.warm_up, daemon=True).start()

    firebase_sync.init(app.config["FIREBASE_CREDENTIALS"], app.config["FIREBASE_COLLECTION"])
    app.register_blueprint(api, url_prefix="/api")

    @app.get("/")
    def index():
        return jsonify({"name": "Smart Mosquito Breeding Spot Detection System", "status": "ok", "api": "/api"})

    @app.get("/api/health")
    def health():
        return jsonify({
            "status": "ok",
            "time": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "detector": detector.info(),
            "firebase": firebase_sync.enabled(),
        })

    @app.get("/uploads/<path:filename>")
    def uploads(filename):
        return send_from_directory(Path(app.config["UPLOAD_DIR"]).resolve(), filename, max_age=86400)

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": "Not found."}), 404

    @app.errorhandler(405)
    def wrong_method(_):
        return jsonify({"error": "This action is not allowed here."}), 405

    @app.errorhandler(413)
    def too_large(_):
        return jsonify({"error": "The photo is too large. Try a smaller image."}), 413

    @app.errorhandler(500)
    def server_error(_):
        return jsonify({"error": "Something went wrong on the server. Try again."}), 500

    return app


if __name__ == "__main__":
    application = create_app()
    application.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
