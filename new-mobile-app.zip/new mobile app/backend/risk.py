"""Risk classification for a detected breeding spot.

Each object type has a weight (how easily it holds stagnant water for a week or
more). The score is the sum of weight x detection confidence, scaled to 0-100.
"""

WEIGHTS = {
    "tyre": 3.0,
    "water_tank": 3.0,
    "drain": 3.0,
    "puddle": 3.0,
    "bucket": 2.0,
    "flower_pot": 2.0,
    "container": 2.0,
    "plastic_bottle": 1.0,
}

WATER_BONUS = 2.0      # added when the person reports visible standing water
SCORE_SCALE = 15
MEDIUM_THRESHOLD = 30
HIGH_THRESHOLD = 60

LEVEL_ADVICE = {
    "high": "Clean this spot within 24 hours and tell the local health or municipal team.",
    "medium": "Clean this spot within 3 days and check it again next week.",
    "low": "Low risk. Empty any water and keep checking regularly.",
}

TIPS = {
    "tyre": "Empty water from tyres and store them under cover, or drill drain holes in them.",
    "bucket": "Turn buckets upside down or keep them covered.",
    "flower_pot": "Empty plant saucers and pot trays at least once a week.",
    "water_tank": "Fit a tight lid or fine mesh on the tank.",
    "drain": "Clear blockages so water flows, and report open drains to the ward office.",
    "plastic_bottle": "Crush and bin bottles, or store them upside down.",
    "puddle": "Drain the water or fill low ground so it cannot stand for more than two days.",
    "container": "Empty containers and store them upside down.",
}


def assess(detections, water_present=False):
    """Return (score, level) for a list of detections."""
    total = sum(WEIGHTS.get(d["label"], 1.0) * float(d["confidence"]) for d in detections)
    if water_present:
        total += WATER_BONUS
    score = min(100, round(total * SCORE_SCALE))
    if score >= HIGH_THRESHOLD:
        level = "high"
    elif score >= MEDIUM_THRESHOLD:
        level = "medium"
    else:
        level = "low"
    return score, level


def advice_for(level, labels):
    items = [LEVEL_ADVICE.get(level, LEVEL_ADVICE["low"])]
    items.extend(TIPS[label] for label in labels if label in TIPS)
    return items
