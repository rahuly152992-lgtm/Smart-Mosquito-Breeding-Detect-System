"""Fine-tune YOLO on your own breeding-spot photos.

    pip install -r ../requirements-ai.txt
    python train_yolo.py --data dataset.yaml --epochs 50
"""
import argparse
import shutil
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data", default=str(Path(__file__).with_name("dataset.yaml")))
    parser.add_argument("--base", default="yolov8n.pt", help="starting weights (n = fastest, s/m = more accurate)")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    args = parser.parse_args()

    from ultralytics import YOLO

    model = YOLO(args.base)
    model.train(data=args.data, epochs=args.epochs, imgsz=args.imgsz, batch=args.batch,
                project=str(Path(__file__).with_name("runs")), name="breeding_spots")

    best = Path(model.trainer.save_dir) / "weights" / "best.pt"
    target = Path(__file__).resolve().parent.parent / "models" / "breeding_spots.pt"
    target.parent.mkdir(exist_ok=True)
    shutil.copy(best, target)
    print(f"\nDone. Weights copied to {target}\nRestart the backend to use them.")


if __name__ == "__main__":
    main()
