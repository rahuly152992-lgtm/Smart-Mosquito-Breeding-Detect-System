"""AI detection of objects that can hold stagnant water.

Three ways to run (set DETECTOR_MODE in `.env`):

* ``yolo``  - real detection with Ultralytics YOLO. Put your trained weights at
              ``models/breeding_spots.pt`` (see ``models/README.md``).
* ``mock``  - simulated detections so the whole app can be demonstrated without a
              model. Every result is flagged ``simulated: true`` and the mobile app
              shows a visible "demo detection" notice.
* ``auto``  - try YOLO, fall back to ``mock`` if it cannot be loaded.
"""
import hashlib
import logging
import os
import random
import threading

import cv2

log = logging.getLogger(__name__)

BREEDING_CLASSES = (
    "tyre", "bucket", "flower_pot", "water_tank",
    "drain", "plastic_bottle", "puddle", "container",
)

# Names a model may use -> the canonical class names above. Anything not listed
# here (for example "person" or "car" from a generic COCO model) is ignored.
ALIASES = {
    "tyre": "tyre", "tyres": "tyre", "tire": "tyre", "tires": "tyre",
    "old tyre": "tyre", "old tire": "tyre",
    "bucket": "bucket", "pail": "bucket",
    "flower pot": "flower_pot", "flowerpot": "flower_pot", "plant pot": "flower_pot",
    "pot": "flower_pot", "potted plant": "flower_pot", "vase": "flower_pot",
    "water tank": "water_tank", "tank": "water_tank", "drum": "water_tank", "barrel": "water_tank",
    "drain": "drain", "open drain": "drain", "clogged drain": "drain", "gutter": "drain",
    "plastic bottle": "plastic_bottle", "bottle": "plastic_bottle",
    "puddle": "puddle", "stagnant water": "puddle", "standing water": "puddle",
    "container": "container", "cup": "container", "bowl": "container",
    "can": "container", "tub": "container", "coconut shell": "container",
}

BOX_COLORS = {  # BGR
    "tyre": (43, 53, 199), "water_tank": (43, 53, 199), "drain": (43, 53, 199), "puddle": (43, 53, 199),
    "bucket": (0, 138, 217), "flower_pot": (0, 138, 217), "container": (0, 138, 217),
    "plastic_bottle": (91, 143, 63),
}


class DetectorUnavailable(RuntimeError):
    """Raised when DETECTOR_MODE=yolo and the model cannot be loaded."""


def normalize_label(name):
    key = str(name).strip().lower().replace("_", " ").replace("-", " ")
    return ALIASES.get(key)


class Detector:
    def __init__(self, mode="auto", model_path="", confidence=0.35):
        self.requested_mode = (mode or "auto").lower()
        self.model_path = model_path
        self.confidence = confidence
        self.active_mode = None       # "yolo" or "mock" once loaded
        self.model_name = None
        self.warning = None
        self.error = None
        self._model = None
        self._lock = threading.Lock()

    # -- loading ---------------------------------------------------------
    def _use_mock(self, reason):
        self.active_mode = "mock"
        self.model_name = None
        self.warning = f"Simulated detections are being used ({reason})."
        log.warning(self.warning)

    def ensure_loaded(self):
        with self._lock:
            if self.active_mode is not None:
                return
            if self.requested_mode == "mock":
                self._use_mock("DETECTOR_MODE=mock")
                return
            try:
                from ultralytics import YOLO  # imported lazily: it is a large dependency

                custom = bool(self.model_path) and os.path.exists(self.model_path)
                weights = self.model_path if custom else "yolov8n.pt"
                self._model = YOLO(weights)
                self.active_mode = "yolo"
                self.model_name = os.path.basename(weights)
                self.error = None
                if not custom:
                    self.warning = (
                        "Generic COCO weights are loaded, so only bottles, cups, bowls, vases and "
                        "potted plants can be recognised. Train custom weights for tyres, buckets, "
                        "tanks, drains and puddles (see backend/models/README.md)."
                    )
                    log.warning(self.warning)
                else:
                    log.info("Loaded custom YOLO weights: %s", weights)
            except Exception as exc:  # noqa: BLE001 - any failure means "no model"
                self.error = f"{exc.__class__.__name__}: {exc}"
                if self.requested_mode == "yolo":
                    raise DetectorUnavailable(self.error) from exc
                self._use_mock(f"YOLO could not be loaded - {self.error}")

    def warm_up(self):
        try:
            self.ensure_loaded()
        except DetectorUnavailable:
            log.error("YOLO is required (DETECTOR_MODE=yolo) but could not be loaded: %s", self.error)

    def info(self):
        return {
            "requested_mode": self.requested_mode,
            "active_mode": self.active_mode or "loading",
            "simulated": self.active_mode != "yolo" if self.active_mode else None,
            "model": self.model_name,
            "warning": self.warning,
            "error": self.error,
        }

    # -- detection -------------------------------------------------------
    def detect(self, image):
        """Return (detections, simulated) for a BGR image (numpy array)."""
        self.ensure_loaded()
        if self.active_mode == "yolo":
            return self._detect_yolo(image), False
        return self._detect_mock(image), True

    def _detect_yolo(self, image):
        result = self._model.predict(image, conf=self.confidence, verbose=False)[0]
        detections = []
        for box in result.boxes:
            label = normalize_label(result.names[int(box.cls[0])])
            if label is None:
                continue
            x1, y1, x2, y2 = (int(v) for v in box.xyxy[0].tolist())
            detections.append({
                "label": label,
                "confidence": round(float(box.conf[0]), 3),
                "box": [x1, y1, x2, y2],
            })
        detections.sort(key=lambda d: d["confidence"], reverse=True)
        return detections[:20]

    def _detect_mock(self, image):
        """Deterministic fake detections: the same photo always gives the same result."""
        small = cv2.resize(image, (32, 32), interpolation=cv2.INTER_AREA)
        rng = random.Random(int.from_bytes(hashlib.sha256(small.tobytes()).digest()[:8], "big"))
        height, width = image.shape[:2]
        detections = []
        for label in rng.sample(BREEDING_CLASSES, rng.choice([1, 2, 2, 3])):
            box_w = int(width * rng.uniform(0.2, 0.4))
            box_h = int(height * rng.uniform(0.2, 0.4))
            x1 = rng.randint(0, max(0, width - box_w))
            y1 = rng.randint(0, max(0, height - box_h))
            detections.append({
                "label": label,
                "confidence": round(rng.uniform(0.55, 0.92), 3),
                "box": [x1, y1, x1 + box_w, y1 + box_h],
            })
        detections.sort(key=lambda d: d["confidence"], reverse=True)
        return detections


def annotate(image, detections):
    """Draw labelled boxes on a copy of the image (the photo evidence shown in the app)."""
    out = image.copy()
    height, width = out.shape[:2]
    thickness = max(2, round(min(height, width) / 200))
    scale = max(0.5, min(height, width) / 900)
    for det in detections:
        x1, y1, x2, y2 = det["box"]
        color = BOX_COLORS.get(det["label"], (43, 53, 199))
        cv2.rectangle(out, (x1, y1), (x2, y2), color, thickness)
        text = f'{det["label"].replace("_", " ")} {int(det["confidence"] * 100)}%'
        (text_w, text_h), baseline = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, 1)
        top = max(y1, text_h + baseline + 4)
        cv2.rectangle(out, (x1, top - text_h - baseline - 4), (x1 + text_w + 8, top), color, -1)
        cv2.putText(out, text, (x1 + 4, top - baseline - 2), cv2.FONT_HERSHEY_SIMPLEX,
                    scale, (255, 255, 255), 1, cv2.LINE_AA)
    return out
