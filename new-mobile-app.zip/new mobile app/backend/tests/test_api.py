"""End-to-end API tests.  Run from the backend folder:  python -m unittest discover -s tests -v"""
import io
import os
import shutil
import sys
import tempfile
import unittest

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app import create_app  # noqa: E402
from risk import assess  # noqa: E402


def make_photo(seed=0, size=(240, 320)):
    rng = np.random.default_rng(seed)
    image = rng.integers(0, 255, size=(*size, 3), dtype=np.uint8)
    ok, buffer = cv2.imencode(".jpg", image)
    assert ok
    return io.BytesIO(buffer.tobytes())


class ApiTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.app = create_app({
            "TESTING": True,
            "DATABASE_PATH": os.path.join(self.tmp, "test.db"),
            "UPLOAD_DIR": os.path.join(self.tmp, "uploads"),
            "DETECTOR_MODE": "mock",
            "WARM_UP_DETECTOR": False,
            "DEVICE_API_KEYS": ["device-secret"],
            "FIREBASE_CREDENTIALS": "",
        })
        self.client = self.app.test_client()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    # -- helpers ---------------------------------------------------------
    def register(self, email="asha@example.com", name="Asha"):
        res = self.client.post("/api/auth/register", json={"name": name, "email": email, "password": "secret1"})
        self.assertEqual(res.status_code, 201, res.get_json())
        return {"Authorization": f"Bearer {res.get_json()['token']}"}

    def submit(self, headers, seed=0, lat=19.07, lng=72.87, **extra):
        data = {"latitude": str(lat), "longitude": str(lng), "image": (make_photo(seed), "spot.jpg"), **extra}
        return self.client.post("/api/reports", data=data, headers=headers, content_type="multipart/form-data")


class AuthTests(ApiTestCase):
    def test_register_login_me(self):
        headers = self.register()
        me = self.client.get("/api/auth/me", headers=headers)
        self.assertEqual(me.get_json()["user"]["email"], "asha@example.com")
        login = self.client.post("/api/auth/login", json={"email": "ASHA@example.com", "password": "secret1"})
        self.assertEqual(login.status_code, 200)

    def test_bad_credentials_and_duplicates(self):
        self.register()
        bad = self.client.post("/api/auth/login", json={"email": "asha@example.com", "password": "nope"})
        self.assertEqual(bad.status_code, 401)
        dup = self.client.post("/api/auth/register", json={"name": "A B", "email": "asha@example.com", "password": "secret1"})
        self.assertEqual(dup.status_code, 409)
        short = self.client.post("/api/auth/register", json={"name": "A B", "email": "x@example.com", "password": "123"})
        self.assertEqual(short.status_code, 400)

    def test_endpoints_require_token(self):
        self.assertEqual(self.client.get("/api/reports").status_code, 401)
        self.assertEqual(self.client.get("/api/reports", headers={"Authorization": "Bearer junk"}).status_code, 401)


class ReportTests(ApiTestCase):
    def test_full_report_lifecycle(self):
        headers = self.register()
        res = self.submit(headers, notes="behind the shop", address="Lane 4", water_present="true")
        self.assertEqual(res.status_code, 201, res.get_json())
        body = res.get_json()
        report = body["report"]
        self.assertTrue(body["saved"])
        self.assertTrue(report["simulated"])
        self.assertIn(report["risk_level"], ("low", "medium", "high"))
        self.assertGreaterEqual(len(report["detections"]), 1)
        self.assertEqual(report["status"], "active")
        self.assertEqual(report["reporter"], "Asha")

        # The saved evidence photo is downloadable.
        with self.client.get(report["image_url"]) as image_res:
            self.assertEqual(image_res.status_code, 200)

        listing = self.client.get("/api/reports?status=active", headers=headers).get_json()
        self.assertEqual(listing["total"], 1)

        resolved = self.client.post(f"/api/reports/{report['id']}/resolve", json={"note": "Emptied"}, headers=headers)
        self.assertEqual(resolved.status_code, 200)
        self.assertEqual(resolved.get_json()["report"]["status"], "resolved")
        again = self.client.post(f"/api/reports/{report['id']}/resolve", json={}, headers=headers)
        self.assertEqual(again.status_code, 409)

        self.assertEqual(self.client.get("/api/reports?status=active", headers=headers).get_json()["total"], 0)
        reopened = self.client.post(f"/api/reports/{report['id']}/reopen", headers=headers)
        self.assertEqual(reopened.get_json()["report"]["status"], "active")

    def test_resolve_with_photo(self):
        headers = self.register()
        rid = self.submit(headers).get_json()["report"]["id"]
        res = self.client.post(
            f"/api/reports/{rid}/resolve",
            data={"note": "Cleaned", "image": (make_photo(9), "after.jpg")},
            headers=headers, content_type="multipart/form-data",
        )
        self.assertEqual(res.status_code, 200)
        url = res.get_json()["report"]["resolved_image_url"]
        with self.client.get(url) as image_res:
            self.assertEqual(image_res.status_code, 200)

    def test_validation(self):
        headers = self.register()
        no_photo = self.client.post("/api/reports", data={"latitude": "1", "longitude": "1"}, headers=headers)
        self.assertEqual(no_photo.status_code, 400)
        bad_coords = self.submit(headers, lat=123)
        self.assertEqual(bad_coords.status_code, 400)
        not_image = self.client.post(
            "/api/reports",
            data={"latitude": "1", "longitude": "1", "image": (io.BytesIO(b"hello"), "x.jpg")},
            headers=headers, content_type="multipart/form-data",
        )
        self.assertEqual(not_image.status_code, 400)
        self.assertEqual(self.client.get("/api/reports/999", headers=headers).status_code, 404)

    def test_esp32_device_key(self):
        rejected = self.submit({"X-Device-Key": "wrong"})
        self.assertEqual(rejected.status_code, 401)
        accepted = self.submit({"X-Device-Key": "device-secret"}, lat=19.1, lng=72.9)
        self.assertEqual(accepted.status_code, 201)
        self.assertEqual(accepted.get_json()["report"]["source"], "esp32")

    def test_clean_photo_is_not_saved_unless_requested(self):
        headers = self.register()
        detector = self.app.extensions["detector"]
        detector.ensure_loaded()
        detector._detect_mock = lambda image: []  # simulate "nothing found"
        res = self.submit(headers)
        self.assertEqual(res.status_code, 200)
        self.assertFalse(res.get_json()["saved"])
        forced = self.submit(headers, save_if_clean="true")
        self.assertEqual(forced.status_code, 201)
        self.assertEqual(forced.get_json()["report"]["risk_level"], "low")


class InsightTests(ApiTestCase):
    def test_hotspots_summary_alerts_weekly(self):
        headers = self.register()
        # Three reports within ~50 m of each other, one far away.
        for seed, (lat, lng) in enumerate([(19.0700, 72.8700), (19.0702, 72.8702), (19.0701, 72.8701), (20.5, 73.5)]):
            self.assertEqual(self.submit(headers, seed=seed, lat=lat, lng=lng).status_code, 201)

        hotspots = self.client.get("/api/hotspots", headers=headers).get_json()["hotspots"]
        self.assertEqual(len(hotspots), 1)
        self.assertEqual(hotspots[0]["count"], 3)

        summary = self.client.get("/api/stats/summary", headers=headers).get_json()
        self.assertEqual(summary["total"], 4)
        self.assertEqual(summary["active"], 4)
        self.assertEqual(sum(summary["active_by_risk"].values()), 4)
        self.assertEqual(summary["new_today"], 4)

        alerts = self.client.get("/api/alerts", headers=headers).get_json()
        for alert in alerts["alerts"]:
            self.assertEqual(alert["risk_level"], "high")
        newer = self.client.get(f"/api/alerts?after_id={alerts['latest_id']}", headers=headers).get_json()
        self.assertEqual(newer["alerts"], [])

        weekly = self.client.get("/api/stats/weekly", headers=headers).get_json()
        self.assertEqual(weekly["new_reports"], 4)
        self.assertEqual(len(weekly["daily"]), 7)
        self.assertEqual(sum(d["new"] for d in weekly["daily"]), 4)
        self.assertEqual(sum(weekly["by_risk"].values()), 4)
        last_week = self.client.get("/api/stats/weekly?weeks_ago=1", headers=headers).get_json()
        self.assertEqual(last_week["new_reports"], 0)

    def test_health_is_public(self):
        res = self.client.get("/api/health")
        self.assertEqual(res.status_code, 200)
        self.assertIn("detector", res.get_json())


class RiskTests(unittest.TestCase):
    def test_levels(self):
        self.assertEqual(assess([{"label": "plastic_bottle", "confidence": 0.9}])[1], "low")
        self.assertEqual(assess([{"label": "tyre", "confidence": 0.8}])[1], "medium")
        self.assertEqual(assess([{"label": "tyre", "confidence": 0.8}, {"label": "bucket", "confidence": 0.8}])[1], "high")
        self.assertEqual(assess([], water_present=True)[1], "medium")
        self.assertEqual(assess([]), (0, "low"))


if __name__ == "__main__":
    unittest.main()
